# Hokm Local v1.2 LAN final — verification report

## Checks completed in the available build environment
- Unpacked both supplied ZIP files and inspected the Android project and existing APK.
- Confirmed the supplied APK is a valid ZIP/APK archive and contains the embedded web client.
- Kotlin `GameEngine.kt` compiled independently with `kotlinc` and a smoke test completed successfully.
- Smoke-tested: 52-card identity, initial 5-card Hakem deal, full 13-card deal, unique cards, legal-play progression, first-to-7 hand termination.
- Extracted the embedded Web client JavaScript and passed it through Node.js syntax checking.
- Reviewed LAN architecture: TCP game server (45871), embedded HTTP/WebSocket web server (8080), DNS-SD discovery, Local-Only Hotspot, private-hand filtering, host-side move validation.
- Added a GitHub Actions unit-test step so the Android project tests run before APK assembly.

## Changes in this v1.2 LAN final source
- Added offline QR generation in the Android host lobby for `http://HOST-IP:8080`.
- Added iPhone instructions: connect to host Wi-Fi, scan QR, open Safari; manual IP URL remains available.
- Improved host/join dialogs with scrolling so buttons and text do not get clipped on short landscape screens.
- Increased Android automatic LAN discovery/fallback timing to reduce false "host not found" failures.
- Added WebSocket ping→pong handling for better browser connection stability.
- Web client now calculates follow-suit legality locally and disables illegal cards visually; the host remains authoritative.
- Added visible collected-trick stack indicators on the Android table.
- Added periodic redraw after Local-Only Hotspot starts because some Android builds expose the hotspot interface slightly after the callback.
- Added unit-test scaffolding and made GitHub Actions run tests before building the APK.

## Important limitation
A true four-physical-phone LAN test (Android host + Android clients + iPhone Safari) cannot be performed inside this environment because no Android emulator/device, Android SDK, Wi-Fi adapter, or iPhone is attached. The project must therefore be validated on the actual phones after GitHub Actions produces the new APK.
