package com.amin.hokmlocal

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class HokmEngineTest {
    @Test fun deckHas52UniqueCards() {
        val ids = (0 until 52).map { Card.fromId(it).id }
        assertEquals(52, ids.size)
        assertEquals(52, ids.toSet().size)
    }

    @Test fun initialDealGivesHakemFiveThenEveryoneThirteen() {
        val e = HokmEngine()
        e.newGame()
        e.configureTeams(0, 2)
        e.setHakem(0)
        e.startConfiguredHand()
        assertEquals(Phase.TRUMP, e.phase)
        assertEquals(5, e.handOf(e.hakem).size)
        assertEquals(0, e.handOf(1).size)
        assertTrue(e.chooseTrump(Suit.HEARTS))
        for (p in 0..3) assertEquals(13, e.handOf(p).size)
        assertEquals(52, (0..3).flatMap { e.handOf(it) }.map { it.id }.toSet().size)
    }

    @Test fun followSuitIsRequiredWhenAvailable() {
        val e = HokmEngine()
        e.newGame(); e.configureTeams(0, 2); e.setHakem(0); e.startConfiguredHand(); e.chooseTrump(Suit.SPADES)
        val leader = e.turn
        val lead = e.handOf(leader).first()
        assertTrue(e.play(lead, leader))
        val p = e.turn
        val same = e.handOf(p).firstOrNull { it.suit == lead.suit }
        val other = e.handOf(p).firstOrNull { it.suit != lead.suit }
        if (same != null && other != null) {
            assertTrue(!e.legal(other, p))
            assertTrue(e.legal(same, p))
        }
    }

    @Test fun randomLegalPlayEndsAtSeven() {
        val e = HokmEngine(); e.newGame(); e.configureTeams(0, 2); e.setHakem(0); e.startConfiguredHand(); e.chooseTrump(Suit.CLUBS)
        var guard = 0
        while (e.phase == Phase.PLAY && guard++ < 52) {
            val p = e.turn
            val c = e.handOf(p).firstOrNull { e.legal(it, p) } ?: error("No legal card")
            assertTrue(e.play(c, p))
        }
        assertEquals(Phase.OVER, e.phase)
        assertTrue(e.tricks[0] >= 7 || e.tricks[1] >= 7)
    }
}
