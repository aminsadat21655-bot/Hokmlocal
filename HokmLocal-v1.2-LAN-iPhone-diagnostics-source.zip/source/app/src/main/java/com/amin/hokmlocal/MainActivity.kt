package com.amin.hokmlocal

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.graphics.*
import android.graphics.drawable.ColorDrawable
import android.net.wifi.WifiManager
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Build
import android.provider.Settings
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.text.InputType
import android.view.MotionEvent
import android.view.View
import java.net.*
import android.util.Base64
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread
import kotlin.math.max
import kotlin.math.min
import com.google.zxing.BarcodeFormat
import com.google.zxing.MultiFormatWriter
import com.google.zxing.common.BitMatrix

private class HostServer(private val port: Int = 45871, private val externalSlotProvider: (() -> Int?)? = null) {
    data class Peer(val player: Int, val socket: Socket, val writer: java.io.BufferedWriter)
    private var server: ServerSocket? = null
    @Volatile var running = false
    val peers = CopyOnWriteArrayList<Peer>()
    var onLine: ((Peer, String) -> Unit)? = null
    var onJoin: ((Peer) -> Unit)? = null
    var onLeave: ((Int) -> Unit)? = null

    fun start() {
        thread(isDaemon = true, name = "hokm-host") {
            try {
                server = ServerSocket(port)
                running = true
                while (running) {
                    val socket = server!!.accept()
                    socket.tcpNoDelay = true
                    val slot = externalSlotProvider?.invoke() ?: (1..3).firstOrNull { p -> peers.none { it.player == p } }
                    if (slot == null) { socket.close(); continue }
                    val writer = socket.getOutputStream().bufferedWriter()
                    val peer = Peer(slot, socket, writer)
                    peers.add(peer)
                    writer.write("ASSIGN|$slot\n")
                    writer.flush()
                    onJoin?.invoke(peer)
                    thread(isDaemon = true, name = "hokm-client-$slot") {
                        try {
                            socket.getInputStream().bufferedReader().forEachLine { line -> onLine?.invoke(peer, line) }
                        } catch (_: Exception) { }
                        peers.remove(peer)
                        try { socket.close() } catch (_: Exception) { }
                        onLeave?.invoke(slot)
                    }
                }
            } catch (_: Exception) { }
            running = false
        }
    }

    fun send(peer: Peer, msg: String) {
        thread(isDaemon = true) {
            try { synchronized(peer.writer) { peer.writer.write(msg); peer.writer.newLine(); peer.writer.flush() } }
            catch (_: Exception) { }
        }
    }

    fun broadcast(msgFor: (Int) -> String) = peers.forEach { send(it, msgFor(it.player)) }

    fun stop() {
        running = false
        peers.forEach { try { it.socket.close() } catch (_: Exception) { } }
        peers.clear()
        try { server?.close() } catch (_: Exception) { }
    }
}

private class ClientConnection(private val host: String, private val port: Int = 45871) {
    @Volatile var connected = false
    private var socket: Socket? = null
    private var writer: java.io.BufferedWriter? = null
    var onLine: ((String) -> Unit)? = null
    var onClosed: (() -> Unit)? = null

    fun connect() {
        thread(isDaemon = true, name = "hokm-join") {
            try {
                val s = Socket()
                s.connect(InetSocketAddress(host, port), 5000)
                s.tcpNoDelay = true
                socket = s
                writer = s.getOutputStream().bufferedWriter()
                connected = true
                s.getInputStream().bufferedReader().forEachLine { line -> onLine?.invoke(line) }
            } catch (_: Exception) { }
            connected = false
            onClosed?.invoke()
        }
    }

    fun send(msg: String) {
        thread(isDaemon = true) {
            try { synchronized(this) { writer?.write(msg); writer?.newLine(); writer?.flush() } }
            catch (_: Exception) { }
        }
    }

    fun close() { try { socket?.close() } catch (_: Exception) { } }
}



/** Minimal embedded HTTP + WebSocket server used only by the LAN web client.
 * The Android host serves the game page itself, so an iPhone needs no app and no internet.
 */
private class WebHostServer(private val context: Context, private val port: Int = 8080,
                            private val slotProvider: () -> Int?) {
    data class Peer(val player: Int, val socket: Socket, val out: java.io.OutputStream)
    private var server: ServerSocket? = null
    @Volatile var running = false
    val peers = CopyOnWriteArrayList<Peer>()
    var onJoin: ((Peer) -> Unit)? = null
    var onLine: ((Peer, String) -> Unit)? = null
    var onLeave: ((Int) -> Unit)? = null
    var onError: ((String) -> Unit)? = null

    fun start() {
        if (running) return
        thread(isDaemon = true, name = "taga-hokm-web") {
            try {
                server = ServerSocket(port)
                running = true
                while (running) {
                    val socket = server!!.accept()
                    socket.tcpNoDelay = true
                    thread(isDaemon = true, name = "taga-web-client") { handle(socket) }
                }
            } catch (e: Exception) {
                onError?.invoke(if (e is BindException)
                    "پورت وب ۸۰۸۰ اشغال است؛ میزبان را یک‌بار ببند و دوباره باز کن."
                else "سرور وب iPhone اجرا نشد: ${e.message ?: e.javaClass.simpleName}")
            }
            running = false
        }
    }

    private fun handle(socket: Socket) {
        try {
            val input = socket.getInputStream()
            val out = socket.getOutputStream()
            val request = readHttpHeaders(input)
            val first = request.line
            val upgrade = request.headers.entries.any { it.key.equals("upgrade", true) && it.value.equals("websocket", true) }
            if (upgrade && first.contains("/ws")) {
                val key = request.headers.entries.firstOrNull { it.key.equals("sec-websocket-key", true) }?.value
                    ?: throw java.io.IOException("Missing websocket key")
                val accept = Base64.encodeToString(
                    java.security.MessageDigest.getInstance("SHA-1")
                        .digest((key.trim() + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").toByteArray()), Base64.NO_WRAP
                )
                val response = "HTTP/1.1 101 Switching Protocols\r\n" +
                        "Upgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: $accept\r\n\r\n"
                out.write(response.toByteArray(Charsets.US_ASCII)); out.flush()
                val slot = slotProvider() ?: run { sendClose(out); socket.close(); return }
                val peer = Peer(slot, socket, out)
                peers.add(peer)
                send(peer, "ASSIGN|$slot")
                onJoin?.invoke(peer)
                readFrames(input, out) { message -> onLine?.invoke(peer, message) }
                peers.remove(peer)
                try { socket.close() } catch (_: Exception) { }
                onLeave?.invoke(slot)
            } else {
                val body = context.assets.open("web/index.html").use { it.readBytes() }
                val head = "HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: ${body.size}\r\nCache-Control: no-store\r\nConnection: close\r\n\r\n"
                out.write(head.toByteArray(Charsets.US_ASCII)); out.write(body); out.flush(); socket.close()
            }
        } catch (_: Exception) { try { socket.close() } catch (_: Exception) {} }
    }

    private data class HttpRequest(val line: String, val headers: Map<String,String>)
    private fun readHttpHeaders(input: java.io.InputStream): HttpRequest {
        val b = StringBuilder()
        var state = 0
        while (true) {
            val v = input.read(); if (v < 0) break
            b.append(v.toChar())
            if (b.length >= 4 && b.substring(b.length - 4) == "\r\n\r\n") break
            if (b.length > 12000) throw java.io.IOException("Headers too large")
        }
        val lines = b.toString().split("\r\n")
        val headers = linkedMapOf<String,String>()
        lines.drop(1).forEach { line ->
            val i = line.indexOf(':')
            if (i > 0) headers[line.substring(0,i).trim()] = line.substring(i+1).trim()
        }
        return HttpRequest(lines.firstOrNull() ?: "", headers)
    }

    private fun readFully(input: java.io.InputStream, buf: ByteArray, off: Int, len: Int): Boolean {
        var got = 0
        while (got < len) { val n = input.read(buf, off + got, len - got); if (n < 0) return false; got += n }
        return true
    }

    private fun readFrames(input: java.io.InputStream, out: java.io.OutputStream, onText: (String) -> Unit) {
        while (true) {
            val h1 = input.read(); val h2 = input.read(); if (h1 < 0 || h2 < 0) return
            val opcode = h1 and 0x0f
            var len = h2 and 0x7f
            val masked = (h2 and 0x80) != 0
            if (len == 126) {
                val b = ByteArray(2); if (!readFully(input,b,0,2)) return
                len = ((b[0].toInt() and 255) shl 8) or (b[1].toInt() and 255)
            } else if (len == 127) {
                val b = ByteArray(8); if (!readFully(input,b,0,8)) return
                var longLen = 0L; for (x in b) longLen = (longLen shl 8) or (x.toLong() and 255)
                if (longLen > 1_000_000) throw java.io.IOException("Frame too large")
                len = longLen.toInt()
            }
            val mask = if (masked) ByteArray(4).also { if (!readFully(input,it,0,4)) return } else ByteArray(4)
            val data = ByteArray(len); if (len > 0 && !readFully(input,data,0,len)) return
            if (masked) for (i in data.indices) data[i] = (data[i].toInt() xor (mask[i % 4].toInt() and 255)).toByte()
            when (opcode) {
                1 -> onText(String(data, Charsets.UTF_8))
                8 -> return
                9 -> { writeControlFrame(out, 10, data) }
                10 -> Unit
            }
        }
    }

    private fun writeControlFrame(out: java.io.OutputStream, opcode: Int, data: ByteArray) {
        if (data.size > 125) return
        out.write(0x80 or (opcode and 0x0f))
        out.write(data.size)
        out.write(data)
        out.flush()
    }

    fun send(peer: Peer, message: String) {
        thread(isDaemon = true) { try { synchronized(peer.out) { writeFrame(peer.out, message) } } catch (_: Exception) {} }
    }
    fun broadcast(messageFor: (Int) -> String) = peers.forEach { send(it, messageFor(it.player)) }
    fun sendClose(out: java.io.OutputStream) { try { out.write(byteArrayOf(0x88.toByte(), 0)); out.flush() } catch (_: Exception) {} }
    private fun writeFrame(out: java.io.OutputStream, text: String) {
        val data = text.toByteArray(Charsets.UTF_8)
        out.write(0x81)
        when {
            data.size < 126 -> out.write(data.size)
            data.size <= 65535 -> { out.write(126); out.write((data.size ushr 8) and 255); out.write(data.size and 255) }
            else -> throw java.io.IOException("Message too large")
        }
        out.write(data); out.flush()
    }
    fun stop() {
        running = false
        peers.forEach { try { sendClose(it.out); it.socket.close() } catch (_: Exception) {} }
        peers.clear(); try { server?.close() } catch (_: Exception) {}
    }
}

class MainActivity : Activity() {
    private lateinit var hokmView: HokmView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setBackgroundDrawable(ColorDrawable(Color.rgb(6, 15, 11)))
        requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        hokmView = HokmView(this)
        setContentView(hokmView)
    }

    @Deprecated("Use OnBackInvokedDispatcher on newer Android versions")
    override fun onBackPressed() {
        if (hokmView.handleBack()) return
        super.onBackPressed()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 7001) {
            hokmView.onWifiPermissionResult(grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED })
        }
    }
}

private class HokmView(ctx: Context) : View(ctx) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG)
    private val engine = HokmEngine()
    private var localPlayer = 0
    private var host: HostServer? = null
    private var webHost: WebHostServer? = null
    private var client: ClientConnection? = null
    private var online = false
    private var lobbyStatus = "آماده"
    private var remoteSnapshot: PublicSnapshot? = null
    private var remoteHand = emptyList<Card>()
    private var lastTouch = 0L
    private var selectedCard = -1
    private var notice = ""
    private var noticeUntil = 0L
    private var hotspotReservation: WifiManager.LocalOnlyHotspotReservation? = null
    private var hotspotSsid = ""
    private var hotspotPassword = ""
    private var hotspotReady = false
    private var hotspotError = ""
    private var webServerError = ""
    private var hostUsesHotspot = false
    private var nsdManager: NsdManager? = null
    private var nsdRegistration: NsdManager.RegistrationListener? = null
    private var nsdDiscovery: NsdManager.DiscoveryListener? = null
    private var autoJoinStarted = false
    private val playerNames = Array(4) { "بازیکن ${it + 1}" }
    private var qrBitmap: Bitmap? = null
    private var qrValue: String = ""

    private val gold = Color.rgb(214, 174, 73)
    private val cream = Color.rgb(248, 244, 228)
    private val felt = Color.rgb(16, 92, 58)
    private val feltDark = Color.rgb(7, 55, 36)
    private val ink = Color.rgb(28, 25, 20)
    private val red = Color.rgb(191, 43, 48)

    private val density = resources.displayMetrics.density
    private fun dp(v: Float): Float = v * density
    private fun sp(v: Float): Float = v * resources.displayMetrics.scaledDensity

    init {
        engine.newGame()
        isFocusable = true
        stroke.style = Paint.Style.STROKE
        stroke.strokeWidth = 2f
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        drawBackground(c, w, h)
        if (!online && host == null && client == null) drawHome(c, w, h)
        else {
            val snap = if (isHost()) engine.snapshotFor(localPlayer) else remoteSnapshot
            if (snap == null) drawConnecting(c, w, h) else drawGame(c, w, h, snap)
        }
        if (notice.isNotBlank() && System.currentTimeMillis() < noticeUntil) {
            drawNotice(c, w, h, notice)
            postInvalidateDelayed(100)
        }
    }

    private fun drawBackground(c: Canvas, w: Float, h: Float) {
        val g = LinearGradient(0f, 0f, 0f, h, Color.rgb(8, 27, 18), Color.rgb(2, 10, 7), Shader.TileMode.CLAMP)
        paint.shader = g
        c.drawRect(0f, 0f, w, h, paint)
        paint.shader = null
    }

    private fun drawHome(c: Canvas, w: Float, h: Float) {
        text(c, "تاغه حکم", w / 2, h * .14f, min(w, h) * .11f, gold, true)
        text(c, "TAGEH HOKM", w / 2, h * .20f, 18f, Color.rgb(205, 194, 158), true)
        drawDivider(c, w / 2, h * .235f, w * .36f)

        glass(c, w * .18f, h * .27f, w * .82f, h * .91f, 30f, Color.argb(95, 255, 255, 255))
        text(c, "چهار نفر • دو تیم • یک میز", w / 2, h * .34f, 27f, cream, true)
        text(c, "چهار نفر • دو روش اتصال • Android + iPhone", w / 2, h * .395f, 18f, Color.rgb(211, 210, 195), false)

        button(c, w / 2, h * .50f, 350f, 78f, "ساخت میز  •  میزبان", true)
        button(c, w / 2, h * .625f, 350f, 78f, "پیوستن به میز", false)
        text(c, "برای بازی واقعی، Android ممکن است برای Wi‑Fi از شما تأیید بخواهد.", w / 2, h * .78f, 16f, Color.rgb(169, 180, 170), false)
        text(c, "بازی چهار نفره محلی • برگشت با دکمه داخل برنامه یا Back گوشی", w / 2, h * .86f, 14f, Color.rgb(137, 154, 143), false)
    }

    private fun drawConnecting(c: Canvas, w: Float, h: Float) {
        drawPanel(c, w * .22f, h * .24f, w * .78f, h * .76f)
        text(c, "پیوستن به میز", w / 2, h * .36f, 30f, cream, true)
        text(c, lobbyStatus, w / 2, h * .46f, 17f, Color.rgb(194, 196, 183), false)
        button(c, w / 2 - 110f, h * .62f, 200f, 62f, "باز کردن Wi‑Fi", false)
        button(c, w / 2 + 110f, h * .62f, 200f, 62f, "انصراف", false)
        text(c, "ابتدا Wi‑Fi را روشن کن و به شبکه میزبان وصل شو، سپس دوباره وارد بازی شو.", w / 2, h * .72f, 13f, Color.rgb(167, 176, 165), false)
    }

    private fun drawGame(c: Canvas, w: Float, h: Float, s: PublicSnapshot) {
        drawTopBar(c, w, s)
        drawTable(c, w, h, s)
        drawPlayers(c, w, h, s)
        drawHand(c, w, h, s)
        drawStatus(c, w, h, s)

        when (s.phase) {
            Phase.LOBBY -> if (isHost()) drawLobby(c, w, h, s)
            Phase.TRUMP -> if (s.turn == localPlayer) drawTrumpChooser(c, w, h)
            Phase.PLAY -> Unit
            Phase.OVER -> drawRoundOver(c, w, h, s)
        }
    }

    private fun drawTopBar(c: Canvas, w: Float, s: PublicSnapshot) {
        paint.color = Color.argb(215, 5, 14, 10)
        c.drawRect(0f, 0f, w, 64f, paint)
        button(c, 70f, 32f, 112f, 42f, "بازگشت", false)
        text(c, "تاغه حکم", 150f, 39f, 20f, cream, true, Paint.Align.LEFT)
        val score = "تیم ۱  ${s.score[0]}   •   ${s.score[1]}  تیم ۲"
        text(c, score, w / 2, 38f, 16f, gold, true)
        pill(c, w - 85f, 32f, 130f, 34f, "${s.tricks[0]}  -  ${s.tricks[1]}")
    }

    private fun drawTable(c: Canvas, w: Float, h: Float, s: PublicSnapshot) {
        val left = w * .18f; val right = w * .82f; val top = h * .18f; val bottom = h * .72f
        paint.color = Color.argb(100, 0, 0, 0)
        c.drawOval(left - 12f, top + 10f, right + 12f, bottom + 22f, paint)
        paint.color = feltDark
        c.drawOval(left, top, right, bottom, paint)
        paint.color = felt
        c.drawOval(left + 8f, top + 8f, right - 8f, bottom - 8f, paint)
        stroke.color = Color.argb(150, 232, 207, 128)
        stroke.strokeWidth = 2f
        c.drawOval(left + 15f, top + 15f, right - 15f, bottom - 15f, stroke)

        val centerX = w / 2f; val centerY = h * .47f
        paint.color = Color.argb(42, 255, 255, 255)
        c.drawCircle(centerX, centerY, min(w, h) * .08f, paint)
        text(c, "حُکم", centerX, centerY + 7f, 18f, Color.argb(155, 245, 237, 210), true)
        if (s.trump != null) {
            text(c, "حکم", centerX, centerY - 20f, 12f, Color.argb(175, 245, 237, 210), false)
            text(c, s.trump!!.symbol, centerX, centerY + 31f, 26f, suitColor(s.trump!!), true)
            // Persistent trump indicator: always visible to every player.
            paint.color = Color.argb(235, 7, 28, 19)
            c.drawRoundRect(w * .735f, h * .205f, w * .805f, h * .305f, 15f, 15f, paint)
            stroke.color = Color.argb(220, 231, 190, 71); stroke.strokeWidth = 2f
            c.drawRoundRect(w * .735f, h * .205f, w * .805f, h * .305f, 15f, 15f, stroke)
            text(c, "حکم", w * .77f, h * .235f, 11f, cream, true)
            text(c, s.trump!!.symbol, w * .77f, h * .285f, 28f, suitColor(s.trump!!), true)
        }
        drawCollectedStacks(c, w, h, s)
        val pos = trickPositions(w, h)
        s.trick.forEachIndexed { i, pc -> drawCard(c, pc.card, pos[i].first, pos[i].second, 44f, 66f, false) }
    }

    private fun drawCollectedStacks(c: Canvas, w: Float, h: Float, s: PublicSnapshot) {
        fun stack(cx: Float, cy: Float, count: Int, label: String) {
            val shown = min(count, 7)
            if (shown <= 0) return
            text(c, label, cx, cy - 28f, 10f, Color.argb(190, 244, 239, 216), true)
            for (i in 0 until shown) {
                val dx = (i - (shown - 1) / 2f) * 6f
                val dy = (i % 3) * 2f
                paint.color = Color.argb(230, 12, 43, 30)
                c.drawRoundRect(cx + dx - 14f, cy + dy - 18f, cx + dx + 14f, cy + dy + 18f, 5f, 5f, paint)
                stroke.color = Color.argb(180, 224, 190, 91); stroke.strokeWidth = 1.2f
                c.drawRoundRect(cx + dx - 14f, cy + dy - 18f, cx + dx + 14f, cy + dy + 18f, 5f, 5f, stroke)
            }
            text(c, "$count چهارکارت", cx, cy + 31f, 10f, Color.argb(185, 215, 210, 193), false)
        }
        stack(w * .27f, h * .39f, s.tricks[0], "تیم ۱")
        stack(w * .73f, h * .39f, s.tricks[1], "تیم ۲")
    }

    private fun drawPlayers(c: Canvas, w: Float, h: Float, s: PublicSnapshot) {
        val labels = playerNames.copyOf()
        val pos = arrayOf(
            Pair(w / 2f, h * .77f), Pair(w * .87f, h * .46f),
            Pair(w / 2f, h * .13f), Pair(w * .13f, h * .46f)
        )
        for (p in 0..3) {
            val active = s.turn == p
            val team = s.teams.getOrElse(p) { engine.teamOf(p) }
            playerBadge(c, pos[p].first, pos[p].second, labels[p], team, p == localPlayer, active, p == s.hakem)
        }
    }

    private fun drawHand(c: Canvas, w: Float, h: Float, s: PublicSnapshot) {
        val hand = if (isHost()) engine.handOf(localPlayer) else remoteHand
        if (hand.isEmpty()) return
        val cardW = min(58f, w / max(10f, hand.size + 2f))
        val gap = cardW * .78f
        val total = gap * (hand.size - 1) + cardW
        val start = w / 2f - total / 2f
        val y = h * .875f
        hand.forEachIndexed { i, card ->
            val x = start + i * gap
            if (i > 0 && hand[i - 1].suit != card.suit) {
                stroke.color = Color.argb(130, 226, 195, 103)
                stroke.strokeWidth = 2f
                c.drawLine(x - gap / 2f, y - 48f, x - gap / 2f, y + 42f, stroke)
            }
            val selectable = s.phase == Phase.PLAY && s.turn == localPlayer && (isHost() && engine.legal(card, localPlayer) || !isHost())
            val lift = if (i == selectedCard) 14f else 0f
            drawCard(c, card, x, y - lift, cardW, 78f, true, selectable)
        }
    }

    private fun drawStatus(c: Canvas, w: Float, h: Float, s: PublicSnapshot) {
        val phaseText = when (s.phase) {
            Phase.LOBBY -> "اتاق بازی"
            Phase.TRUMP -> "انتخاب حکم"
            Phase.PLAY -> "بازی"
            Phase.OVER -> "پایان دست"
        }
        pill(c, w / 2f, h * .82f, 180f, 34f, phaseText)
        text(c, s.message, w / 2f, h * .95f, 13f, Color.rgb(204, 208, 194), false)
        text(c, "حاکم: ${arrayOf("پایین", "راست", "بالا", "چپ")[s.hakem]}   •   ${if (s.trump == null) "حکم تعیین نشده" else "حکم ${s.trump!!.symbol}"}", w / 2f, h * .99f, 11f, Color.rgb(139, 157, 146), false)
    }

    private fun drawLobby(c: Canvas, w: Float, h: Float, s: PublicSnapshot) {
        overlay(c)
        drawPanel(c, w * .07f, h * .07f, w * .93f, h * .93f)
        text(c, "لابی شروع بازی", w / 2, h * .15f, 31f, cream, true)
        val connected = connectedCount() - 1
        val ready = connected >= 3
        pill(c, w / 2, h * .23f, 250f, 44f, if (ready) "۴ / ۴ بازیکن آماده" else "بازیکنان: ${connected + 1} / 4")

        // Left: network and player seats
        text(c, "وضعیت بازیکنان", w * .25f, h * .32f, 20f, gold, true)
        val names = arrayOf("${playerNames[0]} (شما)", playerNames[1], playerNames[2], playerNames[3])
        for (i in 0..3) {
            val connectedSeat = i == 0 || (host?.peers?.any { it.player == i } == true) || (webHost?.peers?.any { it.player == i } == true)
            val yy = h * (.39f + i * .075f)
            pill(c, w * .25f, yy, 270f, 42f, "${names[i]}  •  ${if (connectedSeat) "● متصل" else "○ منتظر"}")
        }
        val ips = localIps()
        val ip = ips.firstOrNull() ?: "IP پیدا نشد"
        if (hostUsesHotspot && hotspotReady) {
            text(c, "حالت: شبکه محلی بدون اینترنت", w * .25f, h * .68f, 16f, cream, true)
            text(c, "Wi‑Fi: $hotspotSsid", w * .25f, h * .73f, 16f, cream, true)
            text(c, "رمز: $hotspotPassword", w * .25f, h * .78f, 16f, gold, true)
            text(c, "IP میزبان: $ip", w * .25f, h * .83f, 16f, cream, true)
            text(c, "iPhone: دوربین را روی QR بگیر → Safari", w * .25f, h * .88f, 14f, gold, true)
            drawQr(c, "http://$ip:8080", w * .105f, h * .69f, min(w, h) * .20f)
        } else if (!hostUsesHotspot) {
            text(c, "حالت: Wi‑Fi / روتر موجود", w * .25f, h * .70f, 17f, cream, true)
            text(c, "همه دستگاه‌ها به یک شبکه واحد وصل باشند؛ Android می‌تواند خودکار پیدا کند.", w * .25f, h * .76f, 14f, Color.rgb(205, 208, 194), false)
            text(c, "IP میزبان: $ip", w * .25f, h * .82f, 16f, cream, true)
            text(c, "iPhone: http://$ip:8080", w * .25f, h * .88f, 15f, gold, true)
            drawQr(c, "http://$ip:8080", w * .105f, h * .69f, min(w, h) * .20f)
        } else {
            text(c, hotspotError.ifBlank { "در حال آماده‌سازی شبکه محلی…" }, w * .25f, h * .74f, 15f, Color.rgb(220, 188, 112), false)
        }
        if (webServerError.isNotBlank()) {
            text(c, webServerError, w * .25f, h * .93f, 13f, Color.rgb(232, 126, 126), true)
        } else if (ips.size > 1) {
            // Vendor hotspot interface names vary.  Showing the alternatives
            // prevents the iPhone from being stranded on a wrong QR address.
            text(c, "IPهای دیگر: ${ips.drop(1).joinToString("  •  ")}", w * .25f, h * .93f, 12f, Color.rgb(190, 205, 191), false)
        }

        // Right: setup controls are shown only at the start of a new match,
        // or after a match is completely finished. Between hands, teams/hakem stay fixed.
        text(c, if (s.setupAllowed) "تنظیمات شروع" else "دست بعد", w * .70f, h * .32f, 20f, gold, true)
        val team0 = (0..3).filter { s.teams.getOrElse(it) { 0 } == 0 }.joinToString(" و ") { names[it].substringBefore(" (") }
        val team1 = (0..3).filter { s.teams.getOrElse(it) { 0 } == 1 }.joinToString(" و ") { names[it].substringBefore(" (") }
        text(c, "تیم ۱: $team0", w * .70f, h * .38f, 17f, cream, true)
        text(c, "تیم ۲: $team1", w * .70f, h * .43f, 17f, cream, true)
        text(c, "حاکم: ${names[s.hakem]}", w * .70f, h * .48f, 17f, gold, true)

        if (s.setupAllowed) {
            button(c, w * .70f, h * .56f, 300f, 56f, "انتخاب هم‌تیمی", false)
            button(c, w * .70f, h * .65f, 300f, 56f, "هم‌تیمی تصادفی", false)
            button(c, w * .70f, h * .74f, 300f, 56f, "انتخاب حاکم", false)
            button(c, w * .70f, h * .83f, 300f, 56f, "حاکم تصادفی", false)
            if (ready) button(c, w * .70f, h * .91f, 300f, 54f, "شروع بازی", true)
            else text(c, "برای شروع، باید هر چهار بازیکن با نام خودشان متصل باشند.", w * .70f, h * .91f, 14f, Color.rgb(170, 180, 170), false)
        } else {
            text(c, "تیم‌ها و حاکم این دست ثابت هستند.", w * .70f, h * .58f, 16f, Color.rgb(185, 190, 179), false)
            button(c, w * .70f, h * .72f, 300f, 60f, "شروع دست بعد", true)
            text(c, "برای تغییر تیم یا حاکم، صبر کن تا کل بازی تمام شود.", w * .70f, h * .84f, 14f, Color.rgb(170, 180, 170), false)
        }
    }



    private fun drawQr(c: Canvas, value: String, left: Float, top: Float, size: Float) {
        if (value.isBlank() || value.contains("IP پیدا نشد")) return
        if (qrValue != value || qrBitmap == null) {
            qrValue = value
            qrBitmap = try {
                val px = size.toInt().coerceIn(120, 420)
                val matrix: BitMatrix = MultiFormatWriter().encode(value, BarcodeFormat.QR_CODE, px, px)
                val bmp = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
                for (x in 0 until px) for (y in 0 until px) {
                    bmp.setPixel(x, y, if (matrix[x, y]) Color.BLACK else Color.WHITE)
                }
                bmp
            } catch (_: Exception) { null }
        }
        val bmp = qrBitmap ?: return
        paint.color = Color.WHITE
        c.drawRoundRect(left - 8f, top - 8f, left + size + 8f, top + size + 8f, 12f, 12f, paint)
        c.drawBitmap(bmp, null, RectF(left, top, left + size, top + size), paint)
        text(c, "اسکن برای iPhone", left + size / 2f, top + size + 24f, 12f, cream, true)
    }

    private fun drawTrumpChooser(c: Canvas, w: Float, h: Float) {
        overlay(c)
        drawPanel(c, w * .20f, h * .20f, w * .80f, h * .80f)
        text(c, "حکم را انتخاب کن", w / 2, h * .33f, 29f, cream, true)
        text(c, "یکی از چهار خال را انتخاب کن", w / 2, h * .39f, 14f, Color.rgb(190, 194, 181), false)
        Suit.values().forEachIndexed { i, suit ->
            val x = w / 2f + (i - 1.5f) * 92f
            suitButton(c, x, h * .54f, suit)
        }
    }

    private fun drawRoundOver(c: Canvas, w: Float, h: Float, s: PublicSnapshot) {
        overlay(c)
        drawPanel(c, w * .22f, h * .16f, w * .78f, h * .86f)
        val winner = if (s.tricks[0] >= 7) 0 else 1
        if (s.matchOver) {
            text(c, "🏆 بازی کاملاً تمام شد", w / 2, h * .30f, 29f, gold, true)
            text(c, "تیم ${winner + 1} قهرمان شد", w / 2, h * .40f, 28f, cream, true)
            text(c, "امتیاز نهایی: ${s.score[0]} - ${s.score[1]}", w / 2, h * .50f, 20f, cream, true)
            if (isHost()) {
                button(c, w / 2, h * .62f, 300f, 58f, "شروع بازی جدید و انتخاب تیم‌ها", true)
                button(c, w / 2, h * .73f, 300f, 58f, "حاکم تصادفی برای بازی جدید", false)
            } else {
                text(c, "میزبان می‌تواند بازی جدید را تنظیم کند…", w / 2, h * .66f, 16f, Color.rgb(185, 190, 179), false)
            }
        } else {
            text(c, "دست تمام شد", w / 2, h * .30f, 20f, Color.rgb(191, 194, 179), false)
            text(c, "تیم ${winner + 1} این دست را برد", w / 2, h * .40f, 29f, gold, true)
            if (s.koot) text(c, "کُت!  •  بازی یک‌طرفه", w / 2, h * .48f, 19f, Color.rgb(239, 204, 96), true)
            text(c, "چهارکارت: ${s.tricks[0]} - ${s.tricks[1]}", w / 2, h * .56f, 18f, cream, false)
            if (isHost()) button(c, w / 2, h * .68f, 250f, 58f, "شروع دست بعد", true)
            else text(c, "میزبان دست بعد را شروع می‌کند…", w / 2, h * .69f, 15f, Color.rgb(185, 190, 179), false)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action != MotionEvent.ACTION_UP) return true
        if (System.currentTimeMillis() - lastTouch < 100) return true
        lastTouch = System.currentTimeMillis()
        val x = e.x; val y = e.y; val w = width.toFloat(); val h = height.toFloat()

        if (!online && host == null && client == null) {
            if (y in h * .43f..h * .56f) chooseHostMode()
            else if (y in h * .56f..h * .69f) askJoin()
            return true
        }

        if (y < 78f && x < 140f) { disconnect(); return true }
        if (!isHost() && remoteSnapshot == null) {
            if (y in h * .55f..h * .69f && x < w / 2f) { openWifiSettings(); return true }
            if (y in h * .55f..h * .69f && x >= w / 2f) { disconnect(); return true }
            return true
        }
        val s = if (isHost()) engine.snapshotFor(localPlayer) else remoteSnapshot ?: return true

        when (s.phase) {
            Phase.LOBBY -> if (isHost()) {
                val connected = connectedCount() - 1
                if (x > w * .55f) {
                    if (!s.setupAllowed) {
                        if (y in h * .64f..h * .80f) { engine.startHand(); broadcastState(); invalidate() }
                    } else {
                        when {
                            y in h * .52f..h * .60f -> if (connected < 3) showNotice("ابتدا هر ۴ بازیکن باید وصل باشند.") else chooseTeammate()
                            y in h * .61f..h * .69f -> if (connected < 3) showNotice("ابتدا هر ۴ بازیکن باید وصل باشند.") else { engine.randomizeTeams(); broadcastState(); invalidate() }
                            y in h * .70f..h * .78f -> if (connected < 3) showNotice("ابتدا هر ۴ بازیکن باید وصل باشند.") else chooseHakem()
                            y in h * .79f..h * .87f -> if (connected < 3) showNotice("ابتدا هر ۴ بازیکن باید وصل باشند.") else { engine.randomizeHakem(); broadcastState(); invalidate() }
                            y in h * .87f..h * .97f -> {
                                if (connected < 3) showNotice("هنوز هر سه بازیکن وصل نشده‌اند.")
                                else { engine.startConfiguredHand(); broadcastState(); invalidate() }
                            }
                        }
                    }
                } else if (x < w * .48f && y in h * .66f..h * .92f) { openWifiSettings(); return true }
            }
            Phase.TRUMP -> if (s.turn == localPlayer && y in h * .45f..h * .64f) {
                val i = (((x - w / 2f) / 92f) + 1.5f).toInt().coerceIn(0, 3)
                if (isHost()) { engine.chooseTrump(Suit.values()[i]); broadcastState() }
                else client?.send("TRUMP|${Suit.values()[i].code}")
                invalidate()
            }
            Phase.PLAY -> if (s.turn == localPlayer && y > h * .79f) {
                val hand = if (isHost()) engine.handOf(localPlayer) else remoteHand
                if (hand.isEmpty()) return true
                val gap = min(58f, w / max(10f, hand.size + 2f)) * .78f
                val cardW = min(58f, w / max(10f, hand.size + 2f))
                val total = gap * (hand.size - 1) + cardW
                val start = w / 2f - total / 2f
                val idx = ((x - start + gap / 2f) / gap).toInt().coerceIn(0, hand.lastIndex)
                val card = hand[idx]
                if (isHost()) {
                    if (engine.play(card, localPlayer)) { selectedCard = -1; broadcastState(); invalidate() }
                    else showNotice("این کارت مجاز نیست؛ باید خالِ شروع را بازی کنی.")
                } else {
                    selectedCard = idx
                    client?.send("PLAY|${card.id}")
                    invalidate()
                }
            }
            Phase.OVER -> if (isHost()) {
                if (s.matchOver) {
                    if (y in h * .56f..h * .68f) { engine.newGame(); selectedCard = -1; broadcastState(); invalidate() }
                    else if (y in h * .68f..h * .79f) { engine.newGame(); engine.randomizeTeams(); engine.randomizeHakem(); selectedCard = -1; broadcastState(); invalidate() }
                } else if (y in h * .62f..h * .75f) {
                    engine.prepareNextHand(); selectedCard = -1; broadcastState(); invalidate()
                }
            }
        }
        return true
    }

    fun handleBack(): Boolean {
        return if (online || host != null || client != null) {
            disconnect()
            true
        } else false
    }

    private fun chooseHostMode() {
        val box = android.widget.LinearLayout(context).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(28, 8, 28, 8)
        }
        val info = android.widget.TextView(context).apply {
            text = "روش اتصال را انتخاب کن. هر دو حالت بدون اینترنت کار می‌کنند و iPhone می‌تواند از Safari وارد شود."
            textSize = 15f
            setTextColor(0xFF555555.toInt())
            setPadding(0, 0, 0, 18)
        }
        fun modeButton(label: String, sub: String): android.widget.Button = android.widget.Button(context).apply {
            text = "$label\n$sub"
            textSize = 16f
            isAllCaps = false
            minHeight = 86
            setPadding(12, 8, 12, 8)
        }
        val hotspot = modeButton("📶  ساخت شبکه محلی", "بدون روتر • بدون اینترنت • میزبان Hotspot می‌سازد")
        val router = modeButton("🌐  استفاده از Wi‑Fi موجود", "اگر هر چهار گوشی به یک روتر/شبکه واحد وصل‌اند")
        box.addView(info, android.widget.LinearLayout.LayoutParams(-1, -2))
        box.addView(hotspot, android.widget.LinearLayout.LayoutParams(-1, 100).apply { bottomMargin = 12 })
        box.addView(router, android.widget.LinearLayout.LayoutParams(-1, 100))
        val scroll = android.widget.ScrollView(context).apply {
            isFillViewport = true
            addView(box)
        }
        val dialog = AlertDialog.Builder(context).setTitle("میزبان شدن").setView(scroll).setNegativeButton("لغو", null).create()
        hotspot.setOnClickListener { dialog.dismiss(); askHostName(true) }
        router.setOnClickListener { dialog.dismiss(); askHostName(false) }
        dialog.show()
    }

    private fun askHostName(useHotspot: Boolean) {
        val input = android.widget.EditText(context)
        input.hint = "مثلاً امین"
        input.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        AlertDialog.Builder(context)
            .setTitle("نام شما")
            .setMessage("نامی که چهار بازیکن در لابی و کنار میز خواهند دید را وارد کن.")
            .setView(input)
            .setNegativeButton("لغو", null)
            .setPositiveButton("ساخت میز") { _, _ ->
                val name = input.text.toString().trim().take(18).ifBlank { "میزبان" }
                startHost(useHotspot, name)
            }.show()
    }

    private fun startHost(useHotspot: Boolean, hostName: String) {
        localPlayer = 0
        hostUsesHotspot = useHotspot
        playerNames[0] = hostName
        online = true
        host = HostServer(45871) {
            val used = mutableSetOf<Int>()
            host?.peers?.forEach { used.add(it.player) }
            webHost?.peers?.forEach { used.add(it.player) }
            (1..3).firstOrNull { it !in used }
        }
        host!!.onJoin = { peer ->
            post { lobbyStatus = "بازیکن جدید وصل شد (${connectedCount()}/4)"; broadcastState(); invalidate() }
        }
        host!!.onLeave = { p -> post { playerNames[p] = "بازیکن ${p + 1}"; lobbyStatus = "بازیکن ${p + 1} قطع شد"; broadcastState(); invalidate() } }
        host!!.onLine = { peer, line -> handleHostLine(peer, line) }
        host!!.start()
        webHost = WebHostServer(context, 8080) {
            val used = mutableSetOf<Int>()
            host?.peers?.forEach { used.add(it.player) }
            webHost?.peers?.forEach { used.add(it.player) }
            (1..3).firstOrNull { it !in used }
        }
        webHost!!.onJoin = { peer -> post { lobbyStatus = "بازیکن مرورگر وصل شد (${connectedCount()}/4)"; broadcastState(); invalidate() } }
        webHost!!.onLeave = { p -> post { playerNames[p] = "بازیکن ${p + 1}"; lobbyStatus = "بازیکن ${p + 1} قطع شد (${connectedCount()}/4)"; broadcastState(); invalidate() } }
        webHost!!.onLine = { peer, line -> handleWebLine(peer, line) }
        webHost!!.onError = { error -> post { webServerError = error; lobbyStatus = error; invalidate() } }
        webHost!!.start()
        registerNsdHost(hostName)
        if (useHotspot) {
            lobbyStatus = "در حال ساخت شبکه محلی…"
            requestWifiPermissionThenHotspot()
        } else {
            hotspotReady = false
            hotspotError = ""
            lobbyStatus = "میز آماده است؛ هر چهار دستگاه را به یک Wi‑Fi/روتر وصل کنید."
        }
        invalidate()
    }

    private fun requestWifiPermissionThenHotspot() {
        if (Build.VERSION.SDK_INT >= 33) {
            if (context.checkSelfPermission("android.permission.NEARBY_WIFI_DEVICES") != PackageManager.PERMISSION_GRANTED) {
                (context as Activity).requestPermissions(arrayOf("android.permission.NEARBY_WIFI_DEVICES"), 7001)
                return
            }
        } else if (Build.VERSION.SDK_INT >= 29 && context.checkSelfPermission("android.permission.ACCESS_FINE_LOCATION") != PackageManager.PERMISSION_GRANTED) {
            (context as Activity).requestPermissions(arrayOf("android.permission.ACCESS_FINE_LOCATION"), 7001)
            return
        }
        startLocalHotspot()
    }

    override fun onDetachedFromWindow() {
        try { hotspotReservation?.close() } catch (_: Exception) {}
        super.onDetachedFromWindow()
    }

    private fun startLocalHotspot() {
        if (Build.VERSION.SDK_INT < 26) {
            hotspotError = "این گوشی شبکه محلی خودکار را پشتیبانی نمی‌کند."
            lobbyStatus = "Wi‑Fi را دستی روشن کن و همه گوشی‌ها را به یک شبکه وصل کن."
            invalidate(); return
        }
        try {
            val wifi = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            wifi.startLocalOnlyHotspot(object : WifiManager.LocalOnlyHotspotCallback() {
                override fun onStarted(reservation: WifiManager.LocalOnlyHotspotReservation) {
                    hotspotReservation = reservation
                    val cfg = reservation.wifiConfiguration
                    hotspotSsid = cfg?.SSID?.trim('"') ?: "شبکه حکم"
                    hotspotPassword = cfg?.preSharedKey ?: ""
                    hotspotReady = true
                    hotspotError = ""
                    lobbyStatus = "شبکه آماده است؛ سه بازیکن وصل شوند."
                    postDelayed({ invalidate() }, 150)
                }
                override fun onStopped() {
                    hotspotReady = false
                    lobbyStatus = "شبکه محلی متوقف شد"
                    post { invalidate() }
                }
                override fun onFailed(reason: Int) {
                    hotspotReady = false
                    hotspotError = "کد خطای Wi‑Fi: $reason"
                    lobbyStatus = "ساخت شبکه خودکار ممکن نشد؛ Wi‑Fi/Hotspot را دستی روشن کن."
                    post { invalidate() }
                }
            }, null)
        } catch (e: SecurityException) {
            hotspotError = "مجوز دستگاه‌های نزدیک داده نشده است."
            lobbyStatus = "مجوز Nearby Wi‑Fi را تأیید کن."
            invalidate()
        } catch (_: Exception) {
            hotspotError = "Hotspot محلی در این گوشی در دسترس نیست."
            lobbyStatus = "Wi‑Fi/Hotspot را دستی روشن کن."
            invalidate()
        }
    }

    private fun openWifiSettings() {
        try {
            val intent = if (Build.VERSION.SDK_INT >= 29) Intent(Settings.Panel.ACTION_WIFI) else Intent(Settings.ACTION_WIFI_SETTINGS)
            context.startActivity(intent)
        } catch (_: Exception) {
            context.startActivity(Intent(Settings.ACTION_WIFI_SETTINGS))
        }
    }

    fun onWifiPermissionResult(granted: Boolean) {
        if (granted) startLocalHotspot()
        else {
            lobbyStatus = "برای ساخت شبکه محلی باید مجوز Wi‑Fi نزدیک را بدهی."
            showNotice("مجوز Nearby Wi‑Fi لازم است.")
        }
        invalidate()
    }

    private fun registerNsdHost(hostName: String) {
        try {
            val mgr = context.getSystemService(Context.NSD_SERVICE) as NsdManager
            nsdManager = mgr
            val info = NsdServiceInfo().apply {
                serviceName = "TagehHokm-${hostName.replace(Regex("[^A-Za-z0-9]"), "").take(12).ifBlank { "Host" }}"
                serviceType = "_taga-hokm._tcp."
                port = 45871
                setAttribute("webport", "8080")
                setAttribute("game", "taga-hokm")
            }
            val listener = object : NsdManager.RegistrationListener {
                override fun onServiceRegistered(serviceInfo: NsdServiceInfo) { }
                override fun onRegistrationFailed(serviceInfo: NsdServiceInfo, errorCode: Int) { }
                override fun onServiceUnregistered(serviceInfo: NsdServiceInfo) { }
                override fun onUnregistrationFailed(serviceInfo: NsdServiceInfo, errorCode: Int) { }
            }
            nsdRegistration = listener
            mgr.registerService(info, NsdManager.PROTOCOL_DNS_SD, listener)
        } catch (_: Exception) { }
    }

    private fun stopNsd() {
        try { nsdManager?.let { mgr -> nsdDiscovery?.let { mgr.stopServiceDiscovery(it) } } } catch (_: Exception) { }
        try { nsdManager?.let { mgr -> nsdRegistration?.let { mgr.unregisterService(it) } } } catch (_: Exception) { }
        nsdDiscovery = null
        nsdRegistration = null
        nsdManager = null
        autoJoinStarted = false
    }

    private fun fallbackFindHost(playerName: String, onStatus: (String) -> Unit, onFound: (String) -> Unit) {
        thread(isDaemon = true, name = "taga-host-scan") {
            try {
                val wifi = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
                val dhcp = wifi?.dhcpInfo
                val gateway = dhcp?.gateway ?: 0
                fun ipFromInt(v: Int): String = listOf(v and 255, (v ushr 8) and 255, (v ushr 16) and 255, (v ushr 24) and 255).joinToString(".")
                val candidates = linkedSetOf<String>()
                if (gateway != 0) candidates.add(ipFromInt(gateway))
                val own = wifi?.connectionInfo?.ipAddress ?: 0
                if (own != 0) {
                    val ownBytes = listOf(own and 255, (own ushr 8) and 255, (own ushr 16) and 255, (own ushr 24) and 255)
                    for (i in 1..254) candidates.add("${ownBytes[0]}.${ownBytes[1]}.${ownBytes[2]}.$i")
                }
                if (candidates.isEmpty()) { post { onStatus("شبکه پیدا نشد؛ IP میزبان را دستی وارد کن.") }; return@thread }
                val pool = Executors.newFixedThreadPool(16)
                val found = AtomicBoolean(false)
                val futures = candidates.map { hostIp ->
                    pool.submit {
                        if (found.get()) return@submit
                        try {
                            Socket().use { socket ->
                                socket.connect(InetSocketAddress(hostIp, 45871), 350)
                                if (found.compareAndSet(false, true)) onFound(hostIp)
                            }
                        } catch (_: Exception) { }
                    }
                }
                pool.shutdown()
                pool.awaitTermination(8500, TimeUnit.MILLISECONDS)
            } catch (_: Exception) { }
        }
    }

    private fun discoverAndJoin(playerName: String, onStatus: (String) -> Unit, onTimeout: () -> Unit) {
        if (autoJoinStarted) return
        autoJoinStarted = true
        try {
            val mgr = (context.getSystemService(Context.NSD_SERVICE) as NsdManager)
            nsdManager = mgr
            val listener = object : NsdManager.DiscoveryListener {
                override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) {
                    autoJoinStarted = false
                    post { onStatus("جستجوی خودکار در دسترس نیست.") }
                    post { onTimeout() }
                }
                override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) { }
                override fun onDiscoveryStarted(serviceType: String) { post { onStatus("در حال جستجوی میز روی همین Wi‑Fi…") } }
                override fun onDiscoveryStopped(serviceType: String) { }
                override fun onServiceFound(serviceInfo: NsdServiceInfo) {
                    if (serviceInfo.serviceType != "_taga-hokm._tcp.") return
                    mgr.resolveService(serviceInfo, object : NsdManager.ResolveListener {
                        override fun onResolveFailed(serviceInfo: NsdServiceInfo, errorCode: Int) { }
                        override fun onServiceResolved(resolved: NsdServiceInfo) {
                            if (autoJoinStarted) {
                                val host = resolved.host?.hostAddress
                                if (!host.isNullOrBlank()) {
                                    autoJoinStarted = false
                                    try { nsdDiscovery?.let { mgr.stopServiceDiscovery(it) } } catch (_: Exception) { }
                                    nsdDiscovery = null
                                    post { onStatus("میز پیدا شد؛ در حال ورود…") }
                                    post { startClient(host, playerName) }
                                }
                            }
                        }
                    })
                }
                override fun onServiceLost(serviceInfo: NsdServiceInfo) { }
            }
            nsdDiscovery = listener
            mgr.discoverServices("_taga-hokm._tcp.", NsdManager.PROTOCOL_DNS_SD, listener)
            postDelayed({
                if (autoJoinStarted) {
                    try { mgr.stopServiceDiscovery(listener) } catch (_: Exception) { }
                    post { onStatus("جستجوی مستقیم شبکه…") }
                    fallbackFindHost(playerName, { msg -> post { onStatus(msg) } }, { hostIp ->
                        if (autoJoinStarted) {
                            autoJoinStarted = false
                            post { onStatus("میز پیدا شد؛ در حال ورود…") }
                            postDelayed({ startClient(hostIp, playerName) }, 250)
                        }
                    })
                    postDelayed({ if (autoJoinStarted) { autoJoinStarted = false; onTimeout() } }, 9500)
                }
            }, 5000)
        } catch (_: Exception) {
            autoJoinStarted = false
            onTimeout()
        }
    }

    private fun askJoin() {
        val box = android.widget.LinearLayout(context).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(24, 6, 24, 6)
        }
        val name = android.widget.EditText(context).apply { hint = "نام شما، مثلاً علی"; textSize = 18f; maxLines = 1 }
        val status = android.widget.TextView(context).apply {
            text = "بعد از زدن «پیوستن خودکار»، برنامه خودش میز تاغه حکم را روی همین شبکه پیدا می‌کند."
            textSize = 15f; setTextColor(0xFF555555.toInt()); setPadding(0, 12, 0, 12)
        }
        val manual = android.widget.Button(context).apply { text = "ورود با IP دستی (اگر پیدا نشد)"; isAllCaps = false; minHeight = 64 }
        val wifi = android.widget.Button(context).apply { text = "باز کردن تنظیمات Wi‑Fi"; isAllCaps = false; minHeight = 64 }
        box.addView(name, android.widget.LinearLayout.LayoutParams(-1, 68))
        box.addView(status, android.widget.LinearLayout.LayoutParams(-1, -2))
        box.addView(manual, android.widget.LinearLayout.LayoutParams(-1, 70))
        box.addView(wifi, android.widget.LinearLayout.LayoutParams(-1, 70))
        val scroll = android.widget.ScrollView(context).apply {
            isFillViewport = true
            addView(box)
        }
        val dialog = AlertDialog.Builder(context)
            .setTitle("پیوستن به میز")
            .setMessage("اول به Hotspot میزبان یا همان روتر وصل شو. لازم نیست IP را وارد کنی؛ جستجوی خودکار را امتحان کن.")
            .setView(scroll)
            .setNegativeButton("لغو", null)
            .setNeutralButton("پیوستن خودکار", null)
            .create()
        manual.setOnClickListener {
            val ip = android.widget.EditText(context).apply { hint = "مثلاً 192.168.1.5"; inputType = InputType.TYPE_CLASS_TEXT }
            AlertDialog.Builder(context)
                .setTitle("آدرس میزبان")
                .setMessage("فقط اگر جستجوی خودکار میز را پیدا نکرد، IP میزبان را وارد کن.")
                .setView(ip)
                .setNegativeButton("لغو", null)
                .setPositiveButton("پیوستن") { _, _ ->
                    val n = name.text.toString().trim().take(18).ifBlank { "بازیکن" }
                    val address = ip.text.toString().trim()
                    if (address.isBlank()) showNotice("IP میزبان را وارد کن.") else { dialog.dismiss(); startClient(address, n) }
                }.show()
        }
        wifi.setOnClickListener { openWifiSettings() }
        dialog.setOnShowListener {
            val auto = dialog.getButton(AlertDialog.BUTTON_NEUTRAL)
            auto.setOnClickListener {
                val n = name.text.toString().trim().take(18).ifBlank { "بازیکن" }
                status.text = "🔍 در حال جستجوی خودکار میز…"
                auto.isEnabled = false
                discoverAndJoin(n, { msg -> post { status.text = msg } }, {
                    post { status.text = "❌ میز پیدا نشد. مطمئن شو به همان Wi‑Fi وصل هستی؛ سپس IP میزبان را دستی وارد کن." }
                    auto.isEnabled = true
                })
            }
        }
        dialog.show()
    }

    private fun startClient(ip: String, playerName: String) {
        if (ip.isBlank()) { showNotice("IP میزبان را وارد کن."); return }
        try {
            val wifi = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
            if (wifi != null && !wifi.isWifiEnabled) {
                openWifiSettings()
                showNotice("Wi‑Fi خاموش است؛ آن را روشن کن و به شبکه میزبان وصل شو.")
            }
        } catch (_: Exception) { }
        online = true
        lobbyStatus = "در حال اتصال به $ip …"
        client = ClientConnection(ip)
        client!!.onClosed = { post { lobbyStatus = "اتصال قطع شد"; invalidate() } }
        // Install the callback before connect so the ASSIGN frame cannot arrive before the listener.
        client!!.onLine = { line ->
            handleClientLine(line)
            if (line.startsWith("ASSIGN|")) client?.send("NAME|${encode(playerName)}")
        }
        client!!.connect()
        invalidate()
    }


    private fun connectedCount(): Int = 1 + (host?.peers?.size ?: 0) + (webHost?.peers?.size ?: 0)

    private fun handleWebLine(peer: WebHostServer.Peer, line: String) {
        val p = line.split('|')
        when (p.firstOrNull()) {
            "NAME" -> {
                val name = p.getOrNull(1)?.let { decode(it) }?.trim()?.take(18).orEmpty()
                if (name.isNotBlank()) { playerNames[peer.player] = name; broadcastState(); post { invalidate() } }
            }
            "TRUMP" -> if (engine.phase == Phase.TRUMP && engine.turn == peer.player) {
                val code = p.getOrNull(1)?.toIntOrNull() ?: return
                runCatching { engine.chooseTrump(Suit.fromCode(code)) }.getOrNull()
                broadcastState(); post { invalidate() }
            }
            "PLAY" -> if (engine.phase == Phase.PLAY && engine.turn == peer.player) {
                val id = p.getOrNull(1)?.toIntOrNull() ?: return
                runCatching { Card.fromId(id) }.getOrNull()?.let { card ->
                    if (engine.play(card, peer.player)) { broadcastState(); post { invalidate() } }
                }
            }
        }
    }

    private fun handleHostLine(peer: HostServer.Peer, line: String) {
        val p = line.split('|')
        when (p.firstOrNull()) {
            "NAME" -> {
                val name = p.getOrNull(1)?.let { decode(it) }?.trim()?.take(18).orEmpty()
                if (name.isNotBlank()) { playerNames[peer.player] = name; broadcastState(); post { invalidate() } }
            }
            "TRUMP" -> if (engine.phase == Phase.TRUMP && engine.turn == peer.player) {
                val code = p.getOrNull(1)?.toIntOrNull() ?: return
                runCatching { engine.chooseTrump(Suit.fromCode(code)) }.getOrNull()
                broadcastState(); post { invalidate() }
            }
            "PLAY" -> if (engine.phase == Phase.PLAY && engine.turn == peer.player) {
                val id = p.getOrNull(1)?.toIntOrNull() ?: return
                runCatching { Card.fromId(id) }.getOrNull()?.let { card ->
                    if (engine.play(card, peer.player)) { broadcastState(); post { invalidate() } }
                }
            }
        }
    }

    private fun handleClientLine(line: String) {
        val p = line.split('|')
        when (p.firstOrNull()) {
            "ASSIGN" -> { localPlayer = p.getOrNull(1)?.toIntOrNull() ?: -1; post { lobbyStatus = "بازیکن ${localPlayer + 1}؛ منتظر میزبان"; invalidate() } }
            "STATE" -> parseState(p)
        }
    }

    private fun parseState(p: List<String>) {
        if (p.size < 15) return
        try {
            val phase = Phase.valueOf(p[1])
            val hakem = p[2].toInt(); val cutter = p[3].toInt(); val turn = p[4].toInt(); val leader = p[5].toInt()
            val trumpCode = p[6].toInt(); val trump = if (trumpCode < 0) null else Suit.fromCode(trumpCode)
            val scores = p[7].split(',').map { it.toInt() }.toIntArray()
            val tricks = p[8].split(',').map { it.toInt() }.toIntArray()
            val streakTeam = p[9].toInt(); val streakCount = p[10].toInt(); val koot = p[11] == "1"; val cut = p[12].toInt()
            val hand = if (p[13].isBlank()) emptyList() else p[13].split(',').map { Card.fromId(it.toInt()) }
            val trickCards = if (p[14].isBlank()) emptyList() else p[14].split(';').map { q ->
                val a = q.split(','); PlayedCard(a[0].toInt(), Card.fromId(a[1].toInt()))
            }
            val msg = if (p.size > 15) decode(p[15]) else ""
            val teams = if (p.size > 16 && p[16].isNotBlank()) p[16].split(',').map { it.toInt() }.toIntArray() else intArrayOf(0, 1, 0, 1)
            val matchOver = p.getOrNull(17) == "1"
            val setupAllowed = p.getOrNull(18) != "0"
            if (p.size > 20) {
                val ns = p[20].split(',')
                for (i in 0 until minOf(4, ns.size)) playerNames[i] = decode(ns[i]).ifBlank { "بازیکن ${i + 1}" }
            }
            remoteHand = hand
            remoteSnapshot = PublicSnapshot(phase, hakem, cutter, turn, leader, trump, tricks, scores, trickCards, streakTeam, streakCount, phase == Phase.OVER, koot, msg, cut, teams, matchOver, setupAllowed)
            post { lobbyStatus = "متصل — ${if (phase == Phase.LOBBY) "منتظر شروع" else "بازی فعال"}"; invalidate() }
        } catch (_: Exception) { showNotice("داده‌ی بازی نامعتبر دریافت شد.") }
    }

    private fun broadcastState() {
        val h = host ?: return
        h.broadcast { player -> encodeState(player) }
        webHost?.broadcast { player -> encodeState(player) }
        lobbyStatus = "میزبان — ${connectedCount()}/4 متصل"
    }

    private fun hostConnectedMask(): Int {
        var mask = 1
        host?.peers?.forEach { mask = mask or (1 shl it.player) }
        webHost?.peers?.forEach { mask = mask or (1 shl it.player) }
        return mask
    }

    private fun encodeState(player: Int): String {
        val s = engine.snapshotFor(player)
        val hand = if (s.phase == Phase.TRUMP && player != s.hakem) emptyList() else engine.handOf(player)
        val handCsv = hand.joinToString(",") { it.id.toString() }
        val trickCsv = s.trick.joinToString(";") { "${it.player},${it.card.id}" }
        return listOf(
            "STATE", s.phase.name, s.hakem, s.cutter, s.turn, s.leader, s.trump?.code ?: -1,
            s.score.joinToString(","), s.tricks.joinToString(","), s.streakTeam, s.streakCount,
            if (s.koot) 1 else 0, s.cutNumber, handCsv, trickCsv, encode(s.message),
            s.teams.joinToString(","), if (s.matchOver) 1 else 0, if (s.setupAllowed) 1 else 0,
            ((1 shl 0) or hostConnectedMask()).toString(),
            playerNames.joinToString(",") { encode(it) }
        ).joinToString("|")
    }

    private fun encode(s: String): String = Base64.encodeToString(s.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
    private fun decode(s: String): String = try { String(Base64.decode(s, Base64.DEFAULT), Charsets.UTF_8) } catch (_: Exception) { s }
    private fun isHost() = host != null

    private fun disconnect() {
        stopNsd()
        try { host?.stop() } catch (_: Exception) { }
        try { webHost?.stop() } catch (_: Exception) { }
        webHost = null
        webServerError = ""
        try { hotspotReservation?.close() } catch (_: Exception) { }
        hotspotReservation = null; hotspotReady = false; hotspotSsid = ""; hotspotPassword = ""
        try { client?.close() } catch (_: Exception) { }
        host = null; client = null; online = false; remoteSnapshot = null; remoteHand = emptyList(); selectedCard = -1
        engine.newGame();
        for (i in 0..3) playerNames[i] = "بازیکن ${i + 1}"
        hostUsesHotspot = false
        qrBitmap = null; qrValue = ""
        lobbyStatus = "آماده"; invalidate()
    }

    private fun localIps(): List<String> {
        return try {
            val interfaces = NetworkInterface.getNetworkInterfaces().toList()
                .filter { it.isUp && !it.isLoopback && !it.name.lowercase().contains("tun") && !it.name.lowercase().contains("vpn") && !it.name.lowercase().contains("wg") }
            fun ips(ni: NetworkInterface): List<String> = ni.inetAddresses.toList()
                .filterIsInstance<Inet4Address>()
                .mapNotNull { it.hostAddress }
                .filter { ip -> ip != "127.0.0.1" && (ip.startsWith("192.168.") || ip.startsWith("10.") || ip.matches(Regex("172\\.(1[6-9]|2[0-9]|3[0-1])\\..*"))) }
            val hotspotNames = interfaces.filter { n ->
                val x = n.name.lowercase()
                x.contains("ap") || x.contains("softap") || x.contains("swlan") || x.contains("hotspot")
            }.flatMap(::ips)
            val all = interfaces.flatMap(::ips)
            val knownHotspot = listOf("192.168.43.1", "192.168.49.1", "192.168.50.1", "192.168.137.1")
            val preferred = when {
                hostUsesHotspot && hotspotNames.isNotEmpty() -> hotspotNames
                hostUsesHotspot -> knownHotspot.filter { it in all } + all.filter { it.startsWith("192.168.") }
                else -> all.filter { it.startsWith("192.168.") } + all.filter { it.startsWith("10.") }
            }
            (preferred + all).distinct()
        } catch (_: Exception) { emptyList() }
    }

    private fun chooseTeammate() {
        if (!isHost()) return
        val labels = arrayOf("${playerNames[0]} (شما)", playerNames[1], playerNames[2], playerNames[3])
        val checked = (0..3).map { engine.teamOf(it) == 0 }.toBooleanArray()
        AlertDialog.Builder(context)
            .setTitle("انتخاب هم‌تیمی")
            .setMessage("دو بازیکن را انتخاب کن تا تیم ۱ باشند؛ دو نفر باقی‌مانده تیم ۲ می‌شوند.")
            .setMultiChoiceItems(labels, checked) { dialog, which, isChecked ->
                val list = (dialog as AlertDialog).listView
                val selected = (0..3).filter { list.isItemChecked(it) }
                if (selected.size > 2) list.setItemChecked(which, false)
            }
            .setNegativeButton("لغو", null)
            .setPositiveButton("ثبت تیم‌ها") { dialog, _ ->
                val list = (dialog as AlertDialog).listView
                val selected = (0..3).filter { list.isItemChecked(it) }
                if (selected.size == 2) {
                    engine.configureTeams(selected[0], selected[1])
                    broadcastState(); invalidate()
                } else {
                    showNotice("باید دقیقاً دو هم‌تیمی انتخاب کنی.")
                }
            }.show()
    }

    private fun chooseHakem() {
        if (!isHost()) return
        val labels = playerNames.copyOf()
        AlertDialog.Builder(context)
            .setTitle("انتخاب حاکم")
            .setSingleChoiceItems(labels, engine.hakem) { dialog, which ->
                engine.setHakem(which)
                broadcastState(); invalidate()
                dialog.dismiss()
            }
            .setNegativeButton("لغو", null)
            .show()
    }

    private fun showNotice(s: String) { notice = s; noticeUntil = System.currentTimeMillis() + 2400L; invalidate() }

    private fun drawNotice(c: Canvas, w: Float, h: Float, s: String) {
        paint.color = Color.argb(235, 18, 20, 17)
        c.drawRoundRect(w * .25f, h * .80f, w * .75f, h * .90f, 16f, 16f, paint)
        text(c, s, w / 2f, h * .858f, 14f, cream, true)
    }

    private fun drawPanel(c: Canvas, l: Float, t: Float, r: Float, b: Float) {
        paint.color = Color.argb(245, 13, 28, 20)
        c.drawRoundRect(l, t, r, b, 26f, 26f, paint)
        stroke.color = Color.argb(100, 224, 192, 92); stroke.strokeWidth = 1.5f
        c.drawRoundRect(l, t, r, b, 26f, 26f, stroke)
    }

    private fun overlay(c: Canvas) {
        paint.color = Color.argb(205, 0, 0, 0)
        c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
    }

    private fun glass(c: Canvas, l: Float, t: Float, r: Float, b: Float, radius: Float, border: Int) {
        paint.color = Color.argb(125, 10, 26, 18)
        c.drawRoundRect(l, t, r, b, radius, radius, paint)
        stroke.color = border; stroke.strokeWidth = 1.5f
        c.drawRoundRect(l, t, r, b, radius, radius, stroke)
    }

    private fun button(c: Canvas, x: Float, y: Float, ww: Float, hh: Float, label: String, primary: Boolean) {
        val scale = max(1.12f, min(width, height) / 610f)
        val bw = ww * scale
        val bh = hh * scale
        val l = x - bw / 2; val t = y - bh / 2; val r = x + bw / 2; val b = y + bh / 2
        paint.color = if (primary) Color.rgb(157, 118, 35) else Color.rgb(28, 58, 43)
        c.drawRoundRect(l, t + 3f, r, b + 3f, 16f, 16f, paint)
        paint.color = if (primary) Color.rgb(210, 168, 70) else Color.rgb(41, 78, 59)
        c.drawRoundRect(l, t, r, b, 16f, 16f, paint)
        stroke.color = if (primary) Color.rgb(239, 207, 119) else Color.rgb(92, 119, 101)
        stroke.strokeWidth = 1.5f
        c.drawRoundRect(l, t, r, b, 16f, 16f, stroke)
        text(c, label, x, y + 6f, 15f, if (primary) ink else cream, true)
    }

    private fun suitButton(c: Canvas, x: Float, y: Float, suit: Suit) {
        paint.color = Color.argb(235, 247, 243, 228)
        c.drawRoundRect(x - 38f, y - 38f, x + 38f, y + 38f, 18f, 18f, paint)
        stroke.color = suitColor(suit); stroke.strokeWidth = 2.5f
        c.drawRoundRect(x - 38f, y - 38f, x + 38f, y + 38f, 18f, 18f, stroke)
        text(c, suit.symbol, x, y + 13f, 35f, suitColor(suit), true)
    }

    private fun pill(c: Canvas, x: Float, y: Float, ww: Float, hh: Float, label: String) {
        paint.color = Color.argb(125, 255, 255, 255)
        c.drawRoundRect(x - ww / 2, y - hh / 2, x + ww / 2, y + hh / 2, hh / 2, hh / 2, paint)
        text(c, label, x, y + 5f, 13f, cream, true)
    }

    private fun playerBadge(c: Canvas, x: Float, y: Float, label: String, team: Int, local: Boolean, active: Boolean, hakem: Boolean) {
        if (active) {
            paint.color = Color.argb(90, 231, 190, 71)
            c.drawCircle(x, y, 35f, paint)
        }
        paint.color = if (team == 0) Color.rgb(41, 75, 56) else Color.rgb(57, 48, 42)
        c.drawCircle(x, y, 27f, paint)
        stroke.color = if (active) gold else Color.argb(110, 255, 255, 255)
        stroke.strokeWidth = if (active) 3f else 1.2f
        c.drawCircle(x, y, 27f, stroke)
        text(c, label, x, y + 5f, 12f, cream, true)
        if (local) text(c, "تو", x, y + 45f, 10f, gold, true)
        if (hakem) text(c, "حاکم", x, y - 38f, 10f, Color.rgb(240, 207, 107), true)
    }

    private fun drawCard(c: Canvas, card: Card, x: Float, y: Float, ww: Float, hh: Float, faceUp: Boolean, selectable: Boolean = false) {
        paint.color = Color.argb(90, 0, 0, 0)
        c.drawRoundRect(x - ww / 2 + 3f, y - hh / 2 + 5f, x + ww / 2 + 3f, y + hh / 2 + 5f, 9f, 9f, paint)
        paint.color = if (faceUp) cream else Color.rgb(32, 78, 56)
        c.drawRoundRect(x - ww / 2, y - hh / 2, x + ww / 2, y + hh / 2, 9f, 9f, paint)
        stroke.color = if (selectable) gold else Color.argb(100, 0, 0, 0)
        stroke.strokeWidth = if (selectable) 2.2f else 1f
        c.drawRoundRect(x - ww / 2, y - hh / 2, x + ww / 2, y + hh / 2, 9f, 9f, stroke)
        if (faceUp) {
            text(c, card.rank.label, x, y - 8f, min(17f, ww * .30f), ink, true)
            text(c, card.suit.symbol, x, y + 18f, min(22f, ww * .38f), suitColor(card.suit), true)
        } else {
            text(c, "✦", x, y + 7f, 18f, gold, true)
        }
    }

    private fun trickPositions(w: Float, h: Float): Array<Pair<Float, Float>> = arrayOf(
        Pair(w / 2f, h * .36f), Pair(w * .59f, h * .47f),
        Pair(w / 2f, h * .58f), Pair(w * .41f, h * .47f)
    )

    private fun drawDivider(c: Canvas, x: Float, y: Float, ww: Float) {
        stroke.color = Color.argb(150, 214, 174, 73); stroke.strokeWidth = 1f
        c.drawLine(x - ww / 2, y, x + ww / 2, y, stroke)
    }

    private fun suitColor(s: Suit): Int = if (s == Suit.HEARTS || s == Suit.DIAMONDS) red else ink

    private fun text(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int, bold: Boolean, align: Paint.Align = Paint.Align.CENTER) {
        paint.shader = null
        paint.typeface = Typeface.create("sans", if (bold) Typeface.BOLD else Typeface.NORMAL)
        val ui = min(1.35f, max(1.22f, min(width, height) / 540f))
        paint.textSize = size * ui
        paint.textAlign = align; paint.color = color
        c.drawText(s, x, y, paint)
    }
}
