# ساخت APK با گوشی

1. کل محتویات ZIP را در یک مخزن GitHub قرار بده.
2. شاخه‌ی `main` را نگه دار.
3. از بخش Actions، workflow با نام `Build Hokm APK` را اجرا کن.
4. بعد از اتمام، artifact با نام `hokm-local-debug-apk` را باز کن و APK را بگیر.

اگر سرویس ابری دیگری استفاده می‌شود، باید واقعاً Android Gradle Project/Kotlin را build کند؛ سرویس‌های HTML-to-APK برای این پروژه مناسب نیستند.
