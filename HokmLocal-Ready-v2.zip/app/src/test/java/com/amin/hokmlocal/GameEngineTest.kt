package com.amin.hokmlocal

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GameEngineTest {
    @Test fun fullHandDeals13CardsAfterTrump() {
        val e = HokmEngine()
        e.newGame()
        e.startHand(2)
        assertEquals(Phase.TRUMP, e.phase)
        assertEquals(5, e.handOf(e.hakem).size)
        assertTrue(e.handOf(1).isEmpty())
        assertTrue(e.chooseTrump(Suit.SPADES))
        for (p in 0..3) assertEquals(13, e.handOf(p).size)
    }

    @Test fun mustFollowLeadSuitWhenPossible() {
        val e = HokmEngine()
        e.newGame(); e.startHand(2); e.chooseTrump(Suit.HEARTS)
        val leader = e.turn
        val lead = e.handOf(leader).first()
        assertTrue(e.play(lead, leader))
        val next = e.turn
        val sameSuit = e.handOf(next).firstOrNull { it.suit == lead.suit }
        if (sameSuit != null) {
            val offSuit = e.handOf(next).firstOrNull { it.suit != lead.suit }
            if (offSuit != null) assertFalse(e.legal(offSuit, next))
            assertTrue(e.legal(sameSuit, next))
        }
    }

    @Test fun handEndsAtSevenTricksAndNextHandReturnsToLobby() {
        val e = HokmEngine()
        e.newGame(); e.startHand(2); e.chooseTrump(Suit.CLUBS)
        var plays = 0
        while (e.phase == Phase.PLAY && plays < 52) {
            val p = e.turn
            val legal = e.handOf(p).filter { e.legal(it, p) }
            assertTrue(legal.isNotEmpty())
            assertTrue(e.play(legal.first(), p))
            plays++
        }
        assertEquals(Phase.OVER, e.phase)
        assertEquals(1, e.score.sum())
        e.prepareNextHand()
        assertEquals(Phase.LOBBY, e.phase)
    }
}
