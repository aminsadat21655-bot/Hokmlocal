package com.amin.hokmlocal

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.graphics.*
import android.graphics.drawable.ColorDrawable
import android.net.wifi.WifiManager
import android.os.Bundle
import android.text.InputType
import android.view.MotionEvent
import android.view.View
import android.view.Window
import java.net.*
import android.util.Base64
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.concurrent.thread

private class HostServer(private val port: Int = 45871) {
    data class Peer(val player: Int, val socket: Socket, val writer: java.io.BufferedWriter)
    private var server: ServerSocket? = null
    @Volatile var running = false
    val peers = CopyOnWriteArrayList<Peer>()
    var onLine: ((Peer, String) -> Unit)? = null
    var onJoin: ((Peer) -> Unit)? = null
    var onLeave: ((Int) -> Unit)? = null

    fun start() {
        thread(isDaemon = true, name = "hokm-host") {
            try {
                server = ServerSocket(port)
                running = true
                while (running) {
                    val socket = server!!.accept()
                    socket.tcpNoDelay = true
                    val used = peers.map { it.player }.toSet()
                    val slot = (1..3).firstOrNull { it !in used }
                    if (slot == null) { socket.close(); continue }
                    val writer = socket.getOutputStream().bufferedWriter()
                    val peer = Peer(slot, socket, writer)
                    peers.add(peer)
                    writer.write("ASSIGN|$slot\n"); writer.flush()
                    onJoin?.invoke(peer)
                    thread(isDaemon = true, name = "hokm-client-$slot") {
                        try {
                            socket.getInputStream().bufferedReader().forEachLine { line -> onLine?.invoke(peer, line) }
                        } catch (_: Exception) { }
                        peers.remove(peer)
                        try { socket.close() } catch (_: Exception) { }
                        onLeave?.invoke(slot)
                    }
                }
            } catch (_: Exception) { }
            running = false
        }
    }

    fun send(peer: Peer, msg: String) {
        thread(isDaemon = true) {
            try { synchronized(peer.writer) { peer.writer.write(msg); peer.writer.newLine(); peer.writer.flush() } }
            catch (_: Exception) { }
        }
    }
    fun broadcast(msgFor: (Int) -> String) { peers.forEach { send(it, msgFor(it.player)) } }
    fun stop() {
        running = false
        peers.forEach { try { it.socket.close() } catch (_: Exception) { } }
        peers.clear()
        try { server?.close() } catch (_: Exception) { }
    }
}

private class ClientConnection(private val host: String, private val port: Int = 45871) {
    var player: Int = -1
    @Volatile var connected = false
    private var socket: Socket? = null
    private var writer: java.io.BufferedWriter? = null
    var onLine: ((String) -> Unit)? = null
    var onClosed: (() -> Unit)? = null

    fun connect() {
        thread(isDaemon = true, name = "hokm-join") {
            try {
                val s = Socket()
                s.connect(InetSocketAddress(host, port), 4000)
                s.tcpNoDelay = true
                socket = s
                writer = s.getOutputStream().bufferedWriter()
                connected = true
                s.getInputStream().bufferedReader().forEachLine { line -> onLine?.invoke(line) }
            } catch (_: Exception) { }
            connected = false
            onClosed?.invoke()
        }
    }
    fun send(msg: String) {
        thread(isDaemon = true) {
            try { synchronized(this) { writer?.write(msg); writer?.newLine(); writer?.flush() } }
            catch (_: Exception) { }
        }
    }
    fun close() { try { socket?.close() } catch (_: Exception) { } }
}

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setBackgroundDrawable(ColorDrawable(Color.rgb(5, 18, 12)))
        requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        setContentView(HokmView(this))
    }
}

private class HokmView(ctx: Context) : View(ctx) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val engine = HokmEngine()
    private var localPlayer = 0
    private var host: HostServer? = null
    private var client: ClientConnection? = null
    private var online = false
    private var lobbyStatus = "تک‌نفره/آماده‌سازی"
    private var remoteSnapshot: PublicSnapshot? = null
    private var remoteHand = emptyList<Card>()
    private var toastMessage = ""
    private var lastTouch = 0L

    init { engine.newGame(); isFocusable = true }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        paint.color = Color.rgb(6, 63, 40); c.drawRect(0f, 0f, w, h, paint)
        paint.color = Color.rgb(4, 35, 23); c.drawRoundRect(14f, 14f, w - 14f, h - 14f, 26f, 26f, paint)

        if (!online && host == null && client == null) {
            drawHome(c, w, h); return
        }

        val snap = if (isHost()) engine.snapshotFor(localPlayer) else remoteSnapshot
        if (snap == null) { drawConnecting(c, w, h); return }
        drawGame(c, w, h, snap)
    }

    private fun drawHome(c: Canvas, w: Float, h: Float) {
        text(c, "حکم محلی", w / 2, 90f, 34f)
        text(c, "۴ نفر • دو تیم • بدون اینترنت • روی یک وای‌فای", w / 2, 130f, 18f)
        button(c, w / 2, h * .42f, 190f, 58f, "ساختن میز (میزبان)")
        button(c, w / 2, h * .58f, 190f, 58f, "پیوستن به میز")
        text(c, "میزبان بازیکن پایین است؛ سه گوشی دیگر با IP میزبان وصل می‌شوند.", w / 2, h - 55f, 16f)
    }

    private fun drawConnecting(c: Canvas, w: Float, h: Float) {
        text(c, lobbyStatus, w / 2, h / 2, 24f)
    }

    private fun drawGame(c: Canvas, w: Float, h: Float, s: PublicSnapshot) {
        text(c, "حکم محلی", w / 2, 38f, 25f)
        text(c, "تیم ۱: ${s.score[0]}", w - 115f, 36f, 18f)
        text(c, "تیم ۲: ${s.score[1]}", 115f, 36f, 18f)
        text(c, "چهارکارت: ${s.tricks[0]} - ${s.tricks[1]}", w / 2, 67f, 16f)

        val labels = arrayOf("پایین", "راست", "بالا", "چپ")
        text(c, "حاکم: ${labels[s.hakem]}", w / 2, 95f, 16f)
        if (s.trump != null) text(c, "حکم: ${s.trump!!.symbol}", w / 2, 120f, 20f)
        text(c, "نوبت: ${labels[s.turn]}", w / 2, 145f, 16f)

        paint.color = Color.rgb(10, 88, 55); c.drawOval(w * .20f, h * .18f, w * .80f, h * .78f, paint)
        val positions = arrayOf(
            floatArrayOf(w / 2, h * .43f), floatArrayOf(w * .60f, h * .51f),
            floatArrayOf(w / 2, h * .61f), floatArrayOf(w * .40f, h * .51f)
        )
        s.trick.forEachIndexed { i, pc -> card(c, pc.card, positions[i][0], positions[i][1]) }

        val hand = if (isHost()) engine.handOf(localPlayer) else remoteHand
        text(c, "تو: ${labels[localPlayer]}", w / 2, h - 150f, 16f)
        val start = (w - hand.size * 54f) / 2f
        hand.forEachIndexed { i, card -> card(c, card, start + i * 54f, h - 92f) }

        if (s.phase == Phase.TRUMP && s.turn == localPlayer) {
            paint.color = Color.argb(235, 0, 0, 0); c.drawRect(0f, 0f, w, h, paint)
            text(c, "حکم را انتخاب کن", w / 2, h * .31f, 28f)
            Suit.values().forEachIndexed { i, suit -> button(c, w / 2 + (i - 1.5f) * 105f, h * .47f, 76f, 52f, suit.symbol) }
        }

        if (s.phase == Phase.LOBBY && isHost()) {
            paint.color = Color.argb(225, 0, 0, 0); c.drawRect(0f, 0f, w, h, paint)
            text(c, "حاکم: ${labels[s.hakem]}", w / 2, h * .28f, 24f)
            text(c, "کات‌کننده را انتخاب کن", w / 2, h * .36f, 21f)
            button(c, w / 2 - 125f, h * .52f, 105f, 55f, labels[s.hakem])
            button(c, w / 2 + 125f, h * .52f, 105f, 55f, labels[(s.hakem + 2) % 4])
        }

        if (s.phase == Phase.OVER) {
            paint.color = Color.argb(220, 0, 0, 0); c.drawRect(0f, 0f, w, h, paint)
            val winner = s.tricks.indices.maxByOrNull { s.tricks[it] } ?: 0
            text(c, "تیم ${winner + 1} برنده شد${if (s.koot) " — کُت!" else ""}", w / 2, h * .38f, 29f)
            if (isHost()) button(c, w / 2, h * .55f, 180f, 58f, "شروع دست بعد")
        }

        button(c, 100f, 42f, 78f, 38f, "قطع")
        text(c, lobbyStatus, w / 2, h - 24f, 14f)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action != MotionEvent.ACTION_UP) return true
        if (System.currentTimeMillis() - lastTouch < 120) return true
        lastTouch = System.currentTimeMillis()
        val x = e.x; val y = e.y
        val w = width.toFloat(); val h = height.toFloat()

        if (!online && host == null && client == null) {
            if (y in h * .35f..h * .49f) startHost()
            else if (y in h * .51f..h * .66f) askJoin()
            return true
        }
        if (y < 65f && x < 160f) { disconnect(); invalidate(); return true }

        val s = if (isHost()) engine.snapshotFor(localPlayer) else remoteSnapshot ?: return true
        if (s.phase == Phase.LOBBY && isHost()) {
            val leftX = w / 2 - 125f; val rightX = w / 2 + 125f
            if (y in h * .44f..h * .61f) {
                val selected = if (x < w / 2) s.hakem else (s.hakem + 2) % 4
                if (selected == localPlayer) {
                    engine.startHand(selected); broadcastState(); invalidate()
                } else {
                    engine.startHand(selected); broadcastState(); invalidate()
                }
            }
            return true
        }
        if (s.phase == Phase.TRUMP && s.turn == localPlayer) {
            if (y in h * .38f..h * .55f) {
                val i = (((x - w / 2) / 105f) + 1.5f).toInt().coerceIn(0, 3)
                if (isHost()) { engine.chooseTrump(Suit.values()[i]); broadcastState(); invalidate() }
                else { client?.send("TRUMP|${Suit.values()[i].code}") }
            }
            return true
        }
        if (s.phase == Phase.PLAY && s.turn == localPlayer) {
            val hand = if (isHost()) engine.handOf(localPlayer) else remoteHand
            val start = (w - hand.size * 54f) / 2f
            val idx = ((x - start + 27f) / 54f).toInt()
            if (idx in hand.indices && y > h - 145f) {
                val card = hand[idx]
                if (isHost()) { if (engine.play(card, localPlayer)) { broadcastState(); invalidate() } }
                else client?.send("PLAY|${card.id}")
            }
            return true
        }
        if (s.phase == Phase.OVER && isHost() && y in h * .47f..h * .63f) {
            engine.prepareNextHand(); broadcastState(); invalidate(); return true
        }
        return true
    }

    private fun startHost() {
        localPlayer = 0
        online = true
        host = HostServer()
        host!!.onJoin = { peer ->
            post { lobbyStatus = "بازیکن ${peer.player + 1} وصل شد (${host!!.peers.size}/3)"; broadcastState(); invalidate() }
        }
        host!!.onLeave = { p -> post { lobbyStatus = "بازیکن ${p + 1} قطع شد"; invalidate() } }
        host!!.onLine = { peer, line -> handleHostLine(peer, line) }
        host!!.start()
        lobbyStatus = "میزبان فعال — IP: ${localIp()} — ${host!!.peers.size}/3"
        invalidate()
    }

    private fun askJoin() {
        val input = android.widget.EditText(context)
        input.hint = "مثلاً 192.168.1.5"
        input.inputType = InputType.TYPE_CLASS_PHONE
        AlertDialog.Builder(context).setTitle("IP میزبان")
            .setMessage("هر دو گوشی باید روی یک وای‌فای باشند.")
            .setView(input)
            .setNegativeButton("لغو", null)
            .setPositiveButton("پیوستن") { _, _ -> startClient(input.text.toString().trim()) }
            .show()
    }

    private fun startClient(ip: String) {
        if (ip.isBlank()) return
        online = true
        lobbyStatus = "در حال اتصال به $ip ..."
        client = ClientConnection(ip)
        client!!.onLine = { line -> handleClientLine(line) }
        client!!.onClosed = { post { lobbyStatus = "اتصال قطع شد"; invalidate() } }
        client!!.connect()
        invalidate()
    }

    private fun handleHostLine(peer: HostServer.Peer, line: String) {
        val p = line.split('|')
        when (p.firstOrNull()) {
            "TRUMP" -> if (engine.phase == Phase.TRUMP && engine.turn == peer.player) {
                val code = p.getOrNull(1)?.toIntOrNull() ?: return
                engine.chooseTrump(Suit.fromCode(code)); broadcastState(); post { invalidate() }
            }
            "PLAY" -> if (engine.phase == Phase.PLAY && engine.turn == peer.player) {
                val id = p.getOrNull(1)?.toIntOrNull() ?: return
                if (engine.play(Card.fromId(id), peer.player)) { broadcastState(); post { invalidate() } }
            }
        }
    }

    private fun handleClientLine(line: String) {
        val p = line.split('|')
        when (p.firstOrNull()) {
            "ASSIGN" -> { localPlayer = p.getOrNull(1)?.toIntOrNull() ?: -1; post { lobbyStatus = "بازیکن ${localPlayer + 1}؛ منتظر میزبان"; invalidate() } }
            "STATE" -> parseState(p)
        }
    }

    private fun parseState(p: List<String>) {
        if (p.size < 15) return
        try {
            val phase = Phase.valueOf(p[1])
            val hakem = p[2].toInt(); val cutter = p[3].toInt(); val turn = p[4].toInt(); val leader = p[5].toInt()
            val trumpCode = p[6].toInt(); val trump = if (trumpCode < 0) null else Suit.fromCode(trumpCode)
            val scores = p[7].split(',').map { it.toInt() }.toIntArray()
            val tricks = p[8].split(',').map { it.toInt() }.toIntArray()
            val streakTeam = p[9].toInt(); val streakCount = p[10].toInt(); val koot = p[11] == "1"; val cut = p[12].toInt()
            val hand = if (p[13].isBlank()) emptyList() else p[13].split(',').map { Card.fromId(it.toInt()) }
            val trickCards = if (p[14].isBlank()) emptyList() else p[14].split(';').map { q -> val a=q.split(','); PlayedCard(a[0].toInt(), Card.fromId(a[1].toInt())) }
            val msg = if (p.size > 15) decode(p[15]) else ""
            remoteHand = hand
            remoteSnapshot = PublicSnapshot(phase, hakem, cutter, turn, leader, trump, tricks, scores, trickCards, streakTeam, streakCount, phase == Phase.OVER, koot, msg, cut)
            post { lobbyStatus = "متصل — ${if (phase == Phase.LOBBY) "منتظر شروع" else "بازی فعال"}"; invalidate() }
        } catch (_: Exception) { }
    }

    private fun broadcastState() {
        val h = host ?: return
        h.broadcast { player -> encodeState(player) }
        lobbyStatus = "میزبان — ${h.peers.size}/3 متصل"
    }

    private fun encodeState(player: Int): String {
        val s = engine.snapshotFor(player)
        val hand = if (s.phase == Phase.TRUMP && player != s.hakem) emptyList() else engine.handOf(player)
        val handCsv = hand.joinToString(",") { it.id.toString() }
        val trickCsv = s.trick.joinToString(";") { "${it.player},${it.card.id}" }
        return listOf(
            "STATE", s.phase.name, s.hakem, s.cutter, s.turn, s.leader, s.trump?.code ?: -1,
            s.score.joinToString(","), s.tricks.joinToString(","), s.streakTeam, s.streakCount,
            if (s.koot) 1 else 0, s.cutNumber, handCsv, trickCsv, encode(s.message)
        ).joinToString("|")
    }

    private fun encode(s: String): String = Base64.encodeToString(s.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
    private fun decode(s: String): String = try { String(Base64.decode(s, Base64.DEFAULT), Charsets.UTF_8) } catch (_: Exception) { s }

    private fun isHost() = host != null

    private fun disconnect() {
        try { host?.stop() } catch (_: Exception) { }
        try { client?.close() } catch (_: Exception) { }
        host = null; client = null; online = false; remoteSnapshot = null; remoteHand = emptyList()
        engine.newGame(); lobbyStatus = "آماده"; invalidate()
    }

    private fun localIp(): String {
        return try {
            NetworkInterface.getNetworkInterfaces().toList().flatMap { it.inetAddresses.toList() }
                .firstOrNull { it is Inet4Address && !it.isLoopbackAddress }?.hostAddress ?: "IP پیدا نشد"
        } catch (_: Exception) { "IP پیدا نشد" }
    }

    private fun text(c: Canvas, s: String, x: Float, y: Float, size: Float, align: Paint.Align = Paint.Align.CENTER) {
        paint.typeface = Typeface.create("sans", Typeface.NORMAL); paint.textSize = size; paint.textAlign = align; paint.color = Color.WHITE
        c.drawText(s, x, y, paint)
    }

    private fun button(c: Canvas, x: Float, y: Float, ww: Float, hh: Float, label: String) {
        paint.color = Color.rgb(140, 108, 35); c.drawRoundRect(x - ww / 2, y - hh / 2, x + ww / 2, y + hh / 2, 14f, 14f, paint)
        text(c, label, x, y + 7f, 16f)
    }

    private fun card(c: Canvas, card: Card, x: Float, y: Float) {
        val ww = 46f; val hh = 68f
        paint.color = Color.WHITE; c.drawRoundRect(x - ww / 2, y - hh / 2, x + ww / 2, y + hh / 2, 8f, 8f, paint)
        paint.color = if (card.suit == Suit.HEARTS || card.suit == Suit.DIAMONDS) Color.rgb(195, 25, 35) else Color.BLACK
        paint.textSize = 17f; paint.textAlign = Paint.Align.CENTER
        c.drawText(card.rank.label + card.suit.symbol, x, y + 6f, paint)
    }
}
