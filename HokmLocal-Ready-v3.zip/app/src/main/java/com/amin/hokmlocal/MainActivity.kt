package com.amin.hokmlocal

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.graphics.*
import android.graphics.drawable.ColorDrawable
import android.net.wifi.WifiManager
import android.os.Bundle
import android.text.InputType
import android.view.MotionEvent
import android.view.View
import java.net.*
import android.util.Base64
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.concurrent.thread
import kotlin.math.max
import kotlin.math.min

private class HostServer(private val port: Int = 45871) {
    data class Peer(val player: Int, val socket: Socket, val writer: java.io.BufferedWriter)
    private var server: ServerSocket? = null
    @Volatile var running = false
    val peers = CopyOnWriteArrayList<Peer>()
    var onLine: ((Peer, String) -> Unit)? = null
    var onJoin: ((Peer) -> Unit)? = null
    var onLeave: ((Int) -> Unit)? = null

    fun start() {
        thread(isDaemon = true, name = "hokm-host") {
            try {
                server = ServerSocket(port)
                running = true
                while (running) {
                    val socket = server!!.accept()
                    socket.tcpNoDelay = true
                    val used = peers.map { it.player }.toSet()
                    val slot = (1..3).firstOrNull { it !in used }
                    if (slot == null) { socket.close(); continue }
                    val writer = socket.getOutputStream().bufferedWriter()
                    val peer = Peer(slot, socket, writer)
                    peers.add(peer)
                    writer.write("ASSIGN|$slot\n")
                    writer.flush()
                    onJoin?.invoke(peer)
                    thread(isDaemon = true, name = "hokm-client-$slot") {
                        try {
                            socket.getInputStream().bufferedReader().forEachLine { line -> onLine?.invoke(peer, line) }
                        } catch (_: Exception) { }
                        peers.remove(peer)
                        try { socket.close() } catch (_: Exception) { }
                        onLeave?.invoke(slot)
                    }
                }
            } catch (_: Exception) { }
            running = false
        }
    }

    fun send(peer: Peer, msg: String) {
        thread(isDaemon = true) {
            try { synchronized(peer.writer) { peer.writer.write(msg); peer.writer.newLine(); peer.writer.flush() } }
            catch (_: Exception) { }
        }
    }

    fun broadcast(msgFor: (Int) -> String) = peers.forEach { send(it, msgFor(it.player)) }

    fun stop() {
        running = false
        peers.forEach { try { it.socket.close() } catch (_: Exception) { } }
        peers.clear()
        try { server?.close() } catch (_: Exception) { }
    }
}

private class ClientConnection(private val host: String, private val port: Int = 45871) {
    @Volatile var connected = false
    private var socket: Socket? = null
    private var writer: java.io.BufferedWriter? = null
    var onLine: ((String) -> Unit)? = null
    var onClosed: (() -> Unit)? = null

    fun connect() {
        thread(isDaemon = true, name = "hokm-join") {
            try {
                val s = Socket()
                s.connect(InetSocketAddress(host, port), 5000)
                s.tcpNoDelay = true
                socket = s
                writer = s.getOutputStream().bufferedWriter()
                connected = true
                s.getInputStream().bufferedReader().forEachLine { line -> onLine?.invoke(line) }
            } catch (_: Exception) { }
            connected = false
            onClosed?.invoke()
        }
    }

    fun send(msg: String) {
        thread(isDaemon = true) {
            try { synchronized(this) { writer?.write(msg); writer?.newLine(); writer?.flush() } }
            catch (_: Exception) { }
        }
    }

    fun close() { try { socket?.close() } catch (_: Exception) { } }
}

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setBackgroundDrawable(ColorDrawable(Color.rgb(6, 15, 11)))
        requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        setContentView(HokmView(this))
    }
}

private class HokmView(ctx: Context) : View(ctx) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG)
    private val engine = HokmEngine()
    private var localPlayer = 0
    private var host: HostServer? = null
    private var client: ClientConnection? = null
    private var online = false
    private var lobbyStatus = "آماده"
    private var remoteSnapshot: PublicSnapshot? = null
    private var remoteHand = emptyList<Card>()
    private var lastTouch = 0L
    private var selectedCard = -1
    private var notice = ""
    private var noticeUntil = 0L

    private val gold = Color.rgb(214, 174, 73)
    private val cream = Color.rgb(248, 244, 228)
    private val felt = Color.rgb(16, 92, 58)
    private val feltDark = Color.rgb(7, 55, 36)
    private val ink = Color.rgb(28, 25, 20)
    private val red = Color.rgb(191, 43, 48)

    init {
        engine.newGame()
        isFocusable = true
        stroke.style = Paint.Style.STROKE
        stroke.strokeWidth = 2f
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        drawBackground(c, w, h)
        if (!online && host == null && client == null) drawHome(c, w, h)
        else {
            val snap = if (isHost()) engine.snapshotFor(localPlayer) else remoteSnapshot
            if (snap == null) drawConnecting(c, w, h) else drawGame(c, w, h, snap)
        }
        if (notice.isNotBlank() && System.currentTimeMillis() < noticeUntil) {
            drawNotice(c, w, h, notice)
            postInvalidateDelayed(100)
        }
    }

    private fun drawBackground(c: Canvas, w: Float, h: Float) {
        val g = LinearGradient(0f, 0f, 0f, h, Color.rgb(8, 27, 18), Color.rgb(2, 10, 7), Shader.TileMode.CLAMP)
        paint.shader = g
        c.drawRect(0f, 0f, w, h, paint)
        paint.shader = null
    }

    private fun drawHome(c: Canvas, w: Float, h: Float) {
        // Ornamental title
        text(c, "حُکم", w / 2, h * .18f, min(w, h) * .105f, gold, true)
        text(c, "HOKM LOCAL", w / 2, h * .235f, 16f, Color.rgb(190, 180, 148), true)
        drawDivider(c, w / 2, h * .27f, w * .28f)

        glass(c, w * .25f, h * .31f, w * .75f, h * .78f, 26f, Color.argb(80, 255, 255, 255))
        text(c, "چهار نفر، دو تیم، یک میز", w / 2, h * .38f, 22f, cream, false)
        text(c, "بازی محلی بدون اینترنت روی یک شبکه Wi‑Fi", w / 2, h * .43f, 15f, Color.rgb(207, 204, 188), false)
        button(c, w / 2, h * .55f, 230f, 56f, "ساخت میز  •  میزبان", true)
        button(c, w / 2, h * .67f, 230f, 56f, "پیوستن به میز", false)
        text(c, "میزبان پایین میز است؛ سه گوشی دیگر با IP میزبان وصل می‌شوند.", w / 2, h * .86f, 13f, Color.rgb(157, 169, 160), false)
    }

    private fun drawConnecting(c: Canvas, w: Float, h: Float) {
        drawPanel(c, w * .25f, h * .30f, w * .75f, h * .70f)
        text(c, "در حال اتصال…", w / 2, h * .47f, 27f, cream, true)
        text(c, lobbyStatus, w / 2, h * .55f, 16f, Color.rgb(194, 196, 183), false)
        button(c, w / 2, h * .66f, 150f, 48f, "انصراف", false)
    }

    private fun drawGame(c: Canvas, w: Float, h: Float, s: PublicSnapshot) {
        drawTopBar(c, w, s)
        drawTable(c, w, h, s)
        drawPlayers(c, w, h, s)
        drawHand(c, w, h, s)
        drawStatus(c, w, h, s)

        when (s.phase) {
            Phase.LOBBY -> if (isHost()) drawLobby(c, w, h, s)
            Phase.TRUMP -> if (s.turn == localPlayer) drawTrumpChooser(c, w, h)
            Phase.PLAY -> Unit
            Phase.OVER -> drawRoundOver(c, w, h, s)
        }
    }

    private fun drawTopBar(c: Canvas, w: Float, s: PublicSnapshot) {
        paint.color = Color.argb(215, 5, 14, 10)
        c.drawRect(0f, 0f, w, 64f, paint)
        text(c, "حُکم محلی", 28f, 39f, 20f, cream, true, Paint.Align.LEFT)
        val score = "تیم ۱  ${s.score[0]}   •   ${s.score[1]}  تیم ۲"
        text(c, score, w / 2, 38f, 16f, gold, true)
        pill(c, w - 85f, 32f, 130f, 34f, "${s.tricks[0]}  -  ${s.tricks[1]}")
    }

    private fun drawTable(c: Canvas, w: Float, h: Float, s: PublicSnapshot) {
        val left = w * .18f; val right = w * .82f; val top = h * .18f; val bottom = h * .72f
        paint.color = Color.argb(100, 0, 0, 0)
        c.drawOval(left - 12f, top + 10f, right + 12f, bottom + 22f, paint)
        paint.color = feltDark
        c.drawOval(left, top, right, bottom, paint)
        paint.color = felt
        c.drawOval(left + 8f, top + 8f, right - 8f, bottom - 8f, paint)
        stroke.color = Color.argb(150, 232, 207, 128)
        stroke.strokeWidth = 2f
        c.drawOval(left + 15f, top + 15f, right - 15f, bottom - 15f, stroke)

        val centerX = w / 2f; val centerY = h * .47f
        paint.color = Color.argb(42, 255, 255, 255)
        c.drawCircle(centerX, centerY, min(w, h) * .08f, paint)
        text(c, "حُکم", centerX, centerY + 7f, 18f, Color.argb(155, 245, 237, 210), true)
        if (s.trump != null) {
            text(c, "حکم", centerX, centerY - 20f, 12f, Color.argb(175, 245, 237, 210), false)
            text(c, s.trump!!.symbol, centerX, centerY + 31f, 26f, suitColor(s.trump!!), true)
        }
        val pos = trickPositions(w, h)
        s.trick.forEachIndexed { i, pc -> drawCard(c, pc.card, pos[i].first, pos[i].second, 44f, 66f, false) }
    }

    private fun drawPlayers(c: Canvas, w: Float, h: Float, s: PublicSnapshot) {
        val labels = arrayOf("پایین", "راست", "بالا", "چپ")
        val pos = arrayOf(
            Pair(w / 2f, h * .77f), Pair(w * .87f, h * .46f),
            Pair(w / 2f, h * .13f), Pair(w * .13f, h * .46f)
        )
        for (p in 0..3) {
            val active = s.turn == p
            val team = engine.teamOf(p)
            playerBadge(c, pos[p].first, pos[p].second, labels[p], team, p == localPlayer, active, p == s.hakem)
        }
    }

    private fun drawHand(c: Canvas, w: Float, h: Float, s: PublicSnapshot) {
        val hand = if (isHost()) engine.handOf(localPlayer) else remoteHand
        if (hand.isEmpty()) return
        val cardW = min(58f, w / max(10f, hand.size + 2f))
        val gap = cardW * .78f
        val total = gap * (hand.size - 1) + cardW
        val start = w / 2f - total / 2f
        val y = h * .875f
        hand.forEachIndexed { i, card ->
            val x = start + i * gap
            val selectable = s.phase == Phase.PLAY && s.turn == localPlayer && (isHost() && engine.legal(card, localPlayer) || !isHost())
            val lift = if (i == selectedCard) 14f else 0f
            drawCard(c, card, x, y - lift, cardW, 78f, true, selectable)
        }
    }

    private fun drawStatus(c: Canvas, w: Float, h: Float, s: PublicSnapshot) {
        val phaseText = when (s.phase) {
            Phase.LOBBY -> "اتاق بازی"
            Phase.TRUMP -> "انتخاب حکم"
            Phase.PLAY -> "بازی"
            Phase.OVER -> "پایان دست"
        }
        pill(c, w / 2f, h * .82f, 180f, 34f, phaseText)
        text(c, s.message, w / 2f, h * .95f, 13f, Color.rgb(204, 208, 194), false)
        text(c, "حاکم: ${arrayOf("پایین", "راست", "بالا", "چپ")[s.hakem]}   •   ${if (s.trump == null) "حکم تعیین نشده" else "حکم ${s.trump!!.symbol}"}", w / 2f, h * .99f, 11f, Color.rgb(139, 157, 146), false)
    }

    private fun drawLobby(c: Canvas, w: Float, h: Float, s: PublicSnapshot) {
        overlay(c)
        drawPanel(c, w * .25f, h * .18f, w * .75f, h * .82f)
        text(c, "آماده‌سازی میز", w / 2, h * .30f, 28f, cream, true)
        text(c, "۳ بازیکن دیگر باید متصل باشند", w / 2, h * .36f, 15f, Color.rgb(190, 194, 181), false)
        pill(c, w / 2, h * .43f, 190f, 38f, "اتصال: ${host?.peers?.size ?: 0} / 3")
        text(c, "حاکم: ${arrayOf("پایین", "راست", "بالا", "چپ")[s.hakem]}", w / 2, h * .51f, 19f, gold, true)
        text(c, "کات‌کننده را انتخاب کن", w / 2, h * .57f, 15f, cream, false)
        val a = s.hakem; val b = (s.hakem + 2) % 4
        button(c, w / 2 - 105f, h * .68f, 160f, 52f, arrayOf("پایین", "راست", "بالا", "چپ")[a], true)
        button(c, w / 2 + 105f, h * .68f, 160f, 52f, arrayOf("پایین", "راست", "بالا", "چپ")[b], false)
        if ((host?.peers?.size ?: 0) < 3) text(c, "بعد از اتصال هر سه گوشی، یکی از دو گزینه را بزن.", w / 2, h * .76f, 12f, Color.rgb(167, 176, 165), false)
    }

    private fun drawTrumpChooser(c: Canvas, w: Float, h: Float) {
        overlay(c)
        drawPanel(c, w * .20f, h * .20f, w * .80f, h * .80f)
        text(c, "حکم را انتخاب کن", w / 2, h * .33f, 29f, cream, true)
        text(c, "یکی از چهار خال را انتخاب کن", w / 2, h * .39f, 14f, Color.rgb(190, 194, 181), false)
        Suit.values().forEachIndexed { i, suit ->
            val x = w / 2f + (i - 1.5f) * 92f
            suitButton(c, x, h * .54f, suit)
        }
    }

    private fun drawRoundOver(c: Canvas, w: Float, h: Float, s: PublicSnapshot) {
        overlay(c)
        drawPanel(c, w * .25f, h * .22f, w * .75f, h * .78f)
        val winner = if (s.tricks[0] >= 7) 0 else 1
        text(c, "دست تمام شد", w / 2, h * .34f, 18f, Color.rgb(191, 194, 179), false)
        text(c, "تیم ${winner + 1} برنده شد", w / 2, h * .43f, 31f, gold, true)
        if (s.koot) text(c, "کُت!  •  بازی یک‌طرفه", w / 2, h * .51f, 19f, Color.rgb(239, 204, 96), true)
        text(c, "چهارکارت: ${s.tricks[0]} - ${s.tricks[1]}", w / 2, h * .58f, 16f, cream, false)
        if (isHost()) button(c, w / 2, h * .68f, 210f, 56f, "شروع دست بعد", true)
        else text(c, "میزبان دست بعد را شروع می‌کند…", w / 2, h * .69f, 14f, Color.rgb(185, 190, 179), false)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action != MotionEvent.ACTION_UP) return true
        if (System.currentTimeMillis() - lastTouch < 100) return true
        lastTouch = System.currentTimeMillis()
        val x = e.x; val y = e.y; val w = width.toFloat(); val h = height.toFloat()

        if (!online && host == null && client == null) {
            if (y in h * .51f..h * .61f) startHost()
            else if (y in h * .63f..h * .72f) askJoin()
            return true
        }

        if (y < 64f && x < 145f) { disconnect(); return true }
        val s = if (isHost()) engine.snapshotFor(localPlayer) else remoteSnapshot ?: return true

        when (s.phase) {
            Phase.LOBBY -> if (isHost()) {
                if ((host?.peers?.size ?: 0) < 3) { showNotice("هنوز هر سه بازیکن وصل نشده‌اند."); return true }
                if (y in h * .62f..h * .74f) {
                    val selected = if (x < w / 2f) s.hakem else (s.hakem + 2) % 4
                    engine.startHand(selected)
                    broadcastState(); invalidate()
                }
            }
            Phase.TRUMP -> if (s.turn == localPlayer && y in h * .45f..h * .64f) {
                val i = (((x - w / 2f) / 92f) + 1.5f).toInt().coerceIn(0, 3)
                if (isHost()) { engine.chooseTrump(Suit.values()[i]); broadcastState() }
                else client?.send("TRUMP|${Suit.values()[i].code}")
                invalidate()
            }
            Phase.PLAY -> if (s.turn == localPlayer && y > h * .79f) {
                val hand = if (isHost()) engine.handOf(localPlayer) else remoteHand
                if (hand.isEmpty()) return true
                val gap = min(58f, w / max(10f, hand.size + 2f)) * .78f
                val cardW = min(58f, w / max(10f, hand.size + 2f))
                val total = gap * (hand.size - 1) + cardW
                val start = w / 2f - total / 2f
                val idx = ((x - start + gap / 2f) / gap).toInt().coerceIn(0, hand.lastIndex)
                val card = hand[idx]
                if (isHost()) {
                    if (engine.play(card, localPlayer)) { selectedCard = -1; broadcastState(); invalidate() }
                    else showNotice("این کارت مجاز نیست؛ باید خالِ شروع را بازی کنی.")
                } else {
                    selectedCard = idx
                    client?.send("PLAY|${card.id}")
                    invalidate()
                }
            }
            Phase.OVER -> if (isHost() && y in h * .62f..h * .74f) {
                engine.prepareNextHand(); selectedCard = -1; broadcastState(); invalidate()
            }
        }
        return true
    }

    private fun startHost() {
        localPlayer = 0
        online = true
        host = HostServer()
        host!!.onJoin = { peer ->
            post { lobbyStatus = "بازیکن ${peer.player + 1} وصل شد (${host!!.peers.size}/3)"; broadcastState(); invalidate() }
        }
        host!!.onLeave = { p -> post { lobbyStatus = "بازیکن ${p + 1} قطع شد"; invalidate() } }
        host!!.onLine = { peer, line -> handleHostLine(peer, line) }
        host!!.start()
        lobbyStatus = "میزبان فعال — IP: ${localIp()}"
        invalidate()
    }

    private fun askJoin() {
        val input = android.widget.EditText(context)
        input.hint = "مثلاً 192.168.1.5"
        input.inputType = InputType.TYPE_CLASS_TEXT
        AlertDialog.Builder(context).setTitle("پیوستن به میز")
            .setMessage("هر چهار گوشی باید روی یک Wi‑Fi باشند. IP نمایش‌داده‌شده روی گوشی میزبان را وارد کن.")
            .setView(input)
            .setNegativeButton("لغو", null)
            .setPositiveButton("پیوستن") { _, _ -> startClient(input.text.toString().trim()) }
            .show()
    }

    private fun startClient(ip: String) {
        if (ip.isBlank()) { showNotice("IP میزبان را وارد کن."); return }
        online = true
        lobbyStatus = "در حال اتصال به $ip …"
        client = ClientConnection(ip)
        client!!.onLine = { line -> handleClientLine(line) }
        client!!.onClosed = { post { lobbyStatus = "اتصال قطع شد"; invalidate() } }
        client!!.connect()
        invalidate()
    }

    private fun handleHostLine(peer: HostServer.Peer, line: String) {
        val p = line.split('|')
        when (p.firstOrNull()) {
            "TRUMP" -> if (engine.phase == Phase.TRUMP && engine.turn == peer.player) {
                val code = p.getOrNull(1)?.toIntOrNull() ?: return
                runCatching { engine.chooseTrump(Suit.fromCode(code)) }.getOrNull()
                broadcastState(); post { invalidate() }
            }
            "PLAY" -> if (engine.phase == Phase.PLAY && engine.turn == peer.player) {
                val id = p.getOrNull(1)?.toIntOrNull() ?: return
                runCatching { Card.fromId(id) }.getOrNull()?.let { card ->
                    if (engine.play(card, peer.player)) { broadcastState(); post { invalidate() } }
                }
            }
        }
    }

    private fun handleClientLine(line: String) {
        val p = line.split('|')
        when (p.firstOrNull()) {
            "ASSIGN" -> { localPlayer = p.getOrNull(1)?.toIntOrNull() ?: -1; post { lobbyStatus = "بازیکن ${localPlayer + 1}؛ منتظر میزبان"; invalidate() } }
            "STATE" -> parseState(p)
        }
    }

    private fun parseState(p: List<String>) {
        if (p.size < 15) return
        try {
            val phase = Phase.valueOf(p[1])
            val hakem = p[2].toInt(); val cutter = p[3].toInt(); val turn = p[4].toInt(); val leader = p[5].toInt()
            val trumpCode = p[6].toInt(); val trump = if (trumpCode < 0) null else Suit.fromCode(trumpCode)
            val scores = p[7].split(',').map { it.toInt() }.toIntArray()
            val tricks = p[8].split(',').map { it.toInt() }.toIntArray()
            val streakTeam = p[9].toInt(); val streakCount = p[10].toInt(); val koot = p[11] == "1"; val cut = p[12].toInt()
            val hand = if (p[13].isBlank()) emptyList() else p[13].split(',').map { Card.fromId(it.toInt()) }
            val trickCards = if (p[14].isBlank()) emptyList() else p[14].split(';').map { q ->
                val a = q.split(','); PlayedCard(a[0].toInt(), Card.fromId(a[1].toInt()))
            }
            val msg = if (p.size > 15) decode(p[15]) else ""
            remoteHand = hand
            remoteSnapshot = PublicSnapshot(phase, hakem, cutter, turn, leader, trump, tricks, scores, trickCards, streakTeam, streakCount, phase == Phase.OVER, koot, msg, cut)
            post { lobbyStatus = "متصل — ${if (phase == Phase.LOBBY) "منتظر شروع" else "بازی فعال"}"; invalidate() }
        } catch (_: Exception) { showNotice("داده‌ی بازی نامعتبر دریافت شد.") }
    }

    private fun broadcastState() {
        val h = host ?: return
        h.broadcast { player -> encodeState(player) }
        lobbyStatus = "میزبان — ${h.peers.size}/3 متصل"
    }

    private fun encodeState(player: Int): String {
        val s = engine.snapshotFor(player)
        val hand = if (s.phase == Phase.TRUMP && player != s.hakem) emptyList() else engine.handOf(player)
        val handCsv = hand.joinToString(",") { it.id.toString() }
        val trickCsv = s.trick.joinToString(";") { "${it.player},${it.card.id}" }
        return listOf(
            "STATE", s.phase.name, s.hakem, s.cutter, s.turn, s.leader, s.trump?.code ?: -1,
            s.score.joinToString(","), s.tricks.joinToString(","), s.streakTeam, s.streakCount,
            if (s.koot) 1 else 0, s.cutNumber, handCsv, trickCsv, encode(s.message)
        ).joinToString("|")
    }

    private fun encode(s: String): String = Base64.encodeToString(s.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
    private fun decode(s: String): String = try { String(Base64.decode(s, Base64.DEFAULT), Charsets.UTF_8) } catch (_: Exception) { s }
    private fun isHost() = host != null

    private fun disconnect() {
        try { host?.stop() } catch (_: Exception) { }
        try { client?.close() } catch (_: Exception) { }
        host = null; client = null; online = false; remoteSnapshot = null; remoteHand = emptyList(); selectedCard = -1
        engine.newGame(); lobbyStatus = "آماده"; invalidate()
    }

    private fun localIp(): String { try {
        val wifi = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
        val raw = wifi?.connectionInfo?.ipAddress ?: 0
        if (raw != 0) {
            val ip = listOf(raw and 0xff, raw shr 8 and 0xff, raw shr 16 and 0xff, raw shr 24 and 0xff).joinToString(".")
            if (ip != "0.0.0.0") return ip
        }
        return NetworkInterface.getNetworkInterfaces().toList().flatMap { it.inetAddresses.toList() }
            .filterIsInstance<Inet4Address>()
            .firstOrNull {
                !it.isLoopbackAddress && !it.isLinkLocalAddress &&
                    (it.hostAddress.startsWith("192.168.") || it.hostAddress.startsWith("10.") ||
                     it.hostAddress.matches(Regex("172\\.(1[6-9]|2[0-9]|3[0-1])\\..*")))
            }?.hostAddress ?: "IP پیدا نشد"
    } catch (_: Exception) { return "IP پیدا نشد" }
    }

    private fun showNotice(s: String) { notice = s; noticeUntil = System.currentTimeMillis() + 2400L; invalidate() }

    private fun drawNotice(c: Canvas, w: Float, h: Float, s: String) {
        paint.color = Color.argb(235, 18, 20, 17)
        c.drawRoundRect(w * .25f, h * .80f, w * .75f, h * .90f, 16f, 16f, paint)
        text(c, s, w / 2f, h * .858f, 14f, cream, true)
    }

    private fun drawPanel(c: Canvas, l: Float, t: Float, r: Float, b: Float) {
        paint.color = Color.argb(245, 13, 28, 20)
        c.drawRoundRect(l, t, r, b, 26f, 26f, paint)
        stroke.color = Color.argb(100, 224, 192, 92); stroke.strokeWidth = 1.5f
        c.drawRoundRect(l, t, r, b, 26f, 26f, stroke)
    }

    private fun overlay(c: Canvas) {
        paint.color = Color.argb(205, 0, 0, 0)
        c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
    }

    private fun glass(c: Canvas, l: Float, t: Float, r: Float, b: Float, radius: Float, border: Int) {
        paint.color = Color.argb(125, 10, 26, 18)
        c.drawRoundRect(l, t, r, b, radius, radius, paint)
        stroke.color = border; stroke.strokeWidth = 1.5f
        c.drawRoundRect(l, t, r, b, radius, radius, stroke)
    }

    private fun button(c: Canvas, x: Float, y: Float, ww: Float, hh: Float, label: String, primary: Boolean) {
        val l = x - ww / 2; val t = y - hh / 2; val r = x + ww / 2; val b = y + hh / 2
        paint.color = if (primary) Color.rgb(157, 118, 35) else Color.rgb(28, 58, 43)
        c.drawRoundRect(l, t + 3f, r, b + 3f, 16f, 16f, paint)
        paint.color = if (primary) Color.rgb(210, 168, 70) else Color.rgb(41, 78, 59)
        c.drawRoundRect(l, t, r, b, 16f, 16f, paint)
        stroke.color = if (primary) Color.rgb(239, 207, 119) else Color.rgb(92, 119, 101)
        stroke.strokeWidth = 1.5f
        c.drawRoundRect(l, t, r, b, 16f, 16f, stroke)
        text(c, label, x, y + 6f, 15f, if (primary) ink else cream, true)
    }

    private fun suitButton(c: Canvas, x: Float, y: Float, suit: Suit) {
        paint.color = Color.argb(235, 247, 243, 228)
        c.drawRoundRect(x - 38f, y - 38f, x + 38f, y + 38f, 18f, 18f, paint)
        stroke.color = suitColor(suit); stroke.strokeWidth = 2.5f
        c.drawRoundRect(x - 38f, y - 38f, x + 38f, y + 38f, 18f, 18f, stroke)
        text(c, suit.symbol, x, y + 13f, 35f, suitColor(suit), true)
    }

    private fun pill(c: Canvas, x: Float, y: Float, ww: Float, hh: Float, label: String) {
        paint.color = Color.argb(125, 255, 255, 255)
        c.drawRoundRect(x - ww / 2, y - hh / 2, x + ww / 2, y + hh / 2, hh / 2, hh / 2, paint)
        text(c, label, x, y + 5f, 13f, cream, true)
    }

    private fun playerBadge(c: Canvas, x: Float, y: Float, label: String, team: Int, local: Boolean, active: Boolean, hakem: Boolean) {
        if (active) {
            paint.color = Color.argb(90, 231, 190, 71)
            c.drawCircle(x, y, 35f, paint)
        }
        paint.color = if (team == 0) Color.rgb(41, 75, 56) else Color.rgb(57, 48, 42)
        c.drawCircle(x, y, 27f, paint)
        stroke.color = if (active) gold else Color.argb(110, 255, 255, 255)
        stroke.strokeWidth = if (active) 3f else 1.2f
        c.drawCircle(x, y, 27f, stroke)
        text(c, label, x, y + 5f, 12f, cream, true)
        if (local) text(c, "تو", x, y + 45f, 10f, gold, true)
        if (hakem) text(c, "حاکم", x, y - 38f, 10f, Color.rgb(240, 207, 107), true)
    }

    private fun drawCard(c: Canvas, card: Card, x: Float, y: Float, ww: Float, hh: Float, faceUp: Boolean, selectable: Boolean = false) {
        paint.color = Color.argb(90, 0, 0, 0)
        c.drawRoundRect(x - ww / 2 + 3f, y - hh / 2 + 5f, x + ww / 2 + 3f, y + hh / 2 + 5f, 9f, 9f, paint)
        paint.color = if (faceUp) cream else Color.rgb(32, 78, 56)
        c.drawRoundRect(x - ww / 2, y - hh / 2, x + ww / 2, y + hh / 2, 9f, 9f, paint)
        stroke.color = if (selectable) gold else Color.argb(100, 0, 0, 0)
        stroke.strokeWidth = if (selectable) 2.2f else 1f
        c.drawRoundRect(x - ww / 2, y - hh / 2, x + ww / 2, y + hh / 2, 9f, 9f, stroke)
        if (faceUp) {
            text(c, card.rank.label, x, y - 8f, min(17f, ww * .30f), ink, true)
            text(c, card.suit.symbol, x, y + 18f, min(22f, ww * .38f), suitColor(card.suit), true)
        } else {
            text(c, "✦", x, y + 7f, 18f, gold, true)
        }
    }

    private fun trickPositions(w: Float, h: Float): Array<Pair<Float, Float>> = arrayOf(
        Pair(w / 2f, h * .36f), Pair(w * .59f, h * .47f),
        Pair(w / 2f, h * .58f), Pair(w * .41f, h * .47f)
    )

    private fun drawDivider(c: Canvas, x: Float, y: Float, ww: Float) {
        stroke.color = Color.argb(150, 214, 174, 73); stroke.strokeWidth = 1f
        c.drawLine(x - ww / 2, y, x + ww / 2, y, stroke)
    }

    private fun suitColor(s: Suit): Int = if (s == Suit.HEARTS || s == Suit.DIAMONDS) red else ink

    private fun text(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int, bold: Boolean, align: Paint.Align = Paint.Align.CENTER) {
        paint.shader = null
        paint.typeface = Typeface.create("sans", if (bold) Typeface.BOLD else Typeface.NORMAL)
        paint.textSize = size; paint.textAlign = align; paint.color = color
        c.drawText(s, x, y, paint)
    }
}
