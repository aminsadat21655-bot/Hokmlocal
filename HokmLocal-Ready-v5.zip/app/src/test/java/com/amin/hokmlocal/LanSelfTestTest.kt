package com.amin.hokmlocal

import org.junit.Test

class LanSelfTestTest {
    @Test
    fun fourPlayerOfflineLanSimulationPasses() {
        check(LanSelfTest.run().startsWith("OK"))
    }
}
