package com.amin.hokmlocal

import java.io.BufferedReader
import java.io.BufferedWriter
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

/** Offline self-test: validates the game engine and the same TCP style used by LAN play. */
object LanSelfTest {
    fun run(): String {
        testEngine()
        testLoopbackProtocol()
        return "OK ۴ بازیکن مجازی و ارتباط TCP با موفقیت تست شدند"
    }

    private fun testEngine() {
        repeat(100) { round ->
            val e = HokmEngine()
            e.newGame()
            e.startHand(round % 4)
            check(e.handOf(e.hakem).size == 5) { "deal-5" }
            check(e.chooseTrump(Suit.values()[round % 4])) { "trump" }
            check((0..3).all { e.handOf(it).size == 13 }) { "deal-13" }
            val ids = (0..3).flatMap { e.handOf(it) }.map { it.id }
            check(ids.size == 52 && ids.toSet().size == 52) { "duplicate-card" }
            var moves = 0
            while (e.phase == Phase.PLAY && moves < 52) {
                val p = e.turn
                val legal = e.handOf(p).firstOrNull { e.legal(it, p) }
                    ?: error("no-legal-card")
                check(e.play(legal, p)) { "play" }
                moves++
            }
            check(e.phase == Phase.OVER) { "hand-did-not-end" }
            check(e.score.sum() == 1) { "score" }
        }
    }

    private fun testLoopbackProtocol() {
        ServerSocket(0).use { server ->
            val port = server.localPort
            val assigned = CountDownLatch(3)
            val accepted = CountDownLatch(3)
            val nextSlot = java.util.concurrent.atomic.AtomicInteger(0)
            repeat(3) {
                thread(isDaemon = true) {
                    server.accept().use { socket ->
                        val out = socket.getOutputStream().bufferedWriter()
                        val input = socket.getInputStream().bufferedReader()
                        val slot = nextSlot.incrementAndGet()
                        out.write("ASSIGN|$slot\n"); out.flush()
                        val line = input.readLine()
                        check(line == "HELLO|$slot") { "protocol" }
                        assigned.countDown()
                        accepted.countDown()
                    }
                }
            }
            val clients = (1..3).map { slot ->
                Socket("127.0.0.1", port).also { socket ->
                    val out = socket.getOutputStream().bufferedWriter()
                    val input = socket.getInputStream().bufferedReader()
                    val assign = input.readLine()
                    check(assign == "ASSIGN|$slot" || assign.startsWith("ASSIGN|")) { "assign" }
                    val actual = assign.substringAfter('|')
                    out.write("HELLO|$actual\n"); out.flush()
                }
            }
            check(assigned.await(3, TimeUnit.SECONDS)) { "clients" }
            check(accepted.await(3, TimeUnit.SECONDS)) { "server" }
            clients.forEach { it.close() }
        }
    }
}
