# Hokm Local 1.3 — Test Report

## هدف
این نسخه بر پایه نسخه LAN قبلی اصلاح شده و تمرکز آن روی سه مشکل گزارش‌شده است: لابی خودکار Android، ورود مستقیم iPhone/Web از QR یا IP، و مشکلات گرافیکی Landscape.

## بررسی انجام‌شده

1. **GameEngine stress test** — 500 بازی تصادفی کامل اجرا شد.
   - 52 کارت یکتا
   - 13 کارت برای هر بازیکن بعد از حکم
   - Follow Suit
   - پایان دست در رسیدن یک تیم به 7
   - بدون گیرکردن نوبت

2. **Web JavaScript syntax** — `node --check` موفق.

3. **Web protocol smoke test** — پیام `ASSIGN`, ارسال/پردازش `NAME`, سپس `STATE` و نمایش Lobby تست شد.

4. **Kotlin parse check** — فایل‌های GameEngine/MainActivity از نظر syntax بررسی شدند. محیط فعلی Android SDK ندارد، بنابراین خطاهای Android framework قابل Build محلی نیستند.

## اصلاحات اصلی

- Android client در Home به‌صورت خودکار DNS-SD را دنبال می‌کند.
- اگر DNS-SD کار نکند، fallback subnet scan برای پورت بازی وجود دارد.
- Android client پس از دریافت STATE در Phase.LOBBY، خود Lobby را نشان می‌دهد.
- QR میزبان به `http://HOST:8080/?join=1` اشاره می‌کند.
- Web page هنگام باز شدن مستقیماً WebSocket را باز می‌کند و با نام پیش‌فرض وارد Lobby می‌شود؛ انتخاب/تغییر نام داخل Lobby انجام می‌شود.
- Web reconnect خودکار دارد.
- Hotspot بعد از آماده‌شدن interface، NSD را ثبت می‌کند.
- Seat allocation بین TCP و Web با reservation قفل شده است.
- Dialogهای Landscape جمع‌وجورتر شده‌اند.

## تستی که این محیط نمی‌تواند ادعا کند

تست واقعی 4 گوشی هم‌زمان، iPhone Safari، Local-Only Hotspot روی مدل‌های مختلف Android، multicast/NSD روی روترهای مختلف و قطع/وصل فیزیکی دستگاه‌ها در این محیط انجام نشده است.

پس این گزارش **تأیید نرم‌افزاری و static/simulation-level** است، نه تأیید سخت‌افزاری 100٪.
