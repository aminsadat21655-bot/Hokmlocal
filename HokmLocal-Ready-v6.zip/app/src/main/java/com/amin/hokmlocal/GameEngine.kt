package com.amin.hokmlocal

import java.util.Collections
import kotlin.random.Random

enum class Suit(val code: Int, val symbol: String) {
    CLUBS(0, "♣"), DIAMONDS(1, "♦"), HEARTS(2, "♥"), SPADES(3, "♠");
    companion object { fun fromCode(v: Int) = values().first { it.code == v } }
}

enum class Rank(val code: Int, val label: String, val value: Int) {
    TWO(0, "2", 2), THREE(1, "3", 3), FOUR(2, "4", 4), FIVE(3, "5", 5),
    SIX(4, "6", 6), SEVEN(5, "7", 7), EIGHT(6, "8", 8), NINE(7, "9", 9),
    TEN(8, "10", 10), JACK(9, "J", 11), QUEEN(10, "Q", 12), KING(11, "K", 13), ACE(12, "A", 14);
    companion object { fun fromCode(v: Int) = values().first { it.code == v } }
}

data class Card(val suit: Suit, val rank: Rank) {
    val id: Int get() = suit.code * 13 + rank.code
    override fun toString(): String = rank.label + suit.symbol
    companion object {
        fun fromId(id: Int): Card = Card(Suit.fromCode(id / 13), Rank.fromCode(id % 13))
    }
}

data class PlayedCard(val player: Int, val card: Card)

enum class Phase { LOBBY, TRUMP, PLAY, OVER }

data class PublicSnapshot(
    val phase: Phase,
    val hakem: Int,
    val cutter: Int,
    val turn: Int,
    val leader: Int,
    val trump: Suit?,
    val tricks: IntArray,
    val score: IntArray,
    val trick: List<PlayedCard>,
    val streakTeam: Int,
    val streakCount: Int,
    val handOver: Boolean,
    val koot: Boolean,
    val message: String,
    val cutNumber: Int,
    val teams: IntArray = intArrayOf(0, 1, 0, 1),
    val matchOver: Boolean = false,
    val setupAllowed: Boolean = true
)

class HokmEngine {
    val playerNames = arrayOf("پایین", "راست", "بالا", "چپ")
    private var teamOf = intArrayOf(0, 1, 0, 1)
    private var hands = Array(4) { mutableListOf<Card>() }
    private var deck = mutableListOf<Card>()
    private var trick = mutableListOf<PlayedCard>()

    var phase: Phase = Phase.LOBBY
        private set
    var hakem: Int = 0
        private set
    var cutter: Int = 2
        private set
    var turn: Int = 0
        private set
    var leader: Int = 0
        private set
    var trump: Suit? = null
        private set
    var tricks = intArrayOf(0, 0)
        private set
    var score = intArrayOf(0, 0)
        private set
    var streakTeam: Int = -1
        private set
    var streakCount: Int = 0
        private set
    var koot: Boolean = false
        private set
    var message: String = "برای شروع، میزبان کات‌کننده را انتخاب کند."
        private set
    var cutNumber: Int = 0
        private set
    var handWinnerTeam: Int = -1
        private set
    var matchOver: Boolean = false
        private set
    var setupAllowed: Boolean = true
        private set

    companion object { const val MATCH_TARGET = 7 }

    fun newGame() {
        score = intArrayOf(0, 0)
        hakem = 0
        cutter = 2
        phase = Phase.LOBBY
        handWinnerTeam = -1
        matchOver = false
        setupAllowed = true
        teamOf = intArrayOf(0, 1, 0, 1)
        message = "دو تیم و حاکم را انتخاب کنید."
        clearCards()
    }

    /**
     * Starts a hand using the user's cut rule:
     * a member of the Hakem team cuts; that player's opposite teammate becomes Hakem.
     * The deck is cut by moving a counted top packet underneath the rest.
     */
    fun startHand(selectedCutter: Int = cutter) {
        require(selectedCutter in 0..3)
        cutter = selectedCutter
        if (teamOf[cutter] != teamOf[hakem]) cutter = (hakem + 2) % 4
        hakem = (cutter + 2) % 4
        startDeal()
    }

    fun configureTeams(firstPlayer: Int, secondPlayer: Int) {
        require(firstPlayer in 0..3 && secondPlayer in 0..3 && firstPlayer != secondPlayer)
        require(phase == Phase.LOBBY)
        teamOf = IntArray(4) { if (it == firstPlayer || it == secondPlayer) 0 else 1 }
        message = "تیم‌ها انتخاب شدند: ${playerNames[firstPlayer]} و ${playerNames[secondPlayer]} یک تیم هستند."
    }

    fun randomizeTeams() {
        require(phase == Phase.LOBBY)
        val players = (0..3).shuffled()
        configureTeams(players[0], players[1])
    }

    fun setHakem(player: Int) {
        require(player in 0..3)
        require(phase == Phase.LOBBY)
        hakem = player
        cutter = teamOf.indices.first { teamOf[it] == teamOf[player] && it != player }
        message = "حاکم ${playerNames[player]} انتخاب شد."
    }

    fun randomizeHakem() {
        require(phase == Phase.LOBBY)
        setHakem((0..3).random())
    }

    fun startConfiguredHand() {
        require(phase == Phase.LOBBY && setupAllowed)
        cutter = teamOf.indices.first { teamOf[it] == teamOf[hakem] && it != hakem }
        startDeal()
    }

    private fun startDeal() {

        clearCards()
        deck = (0 until 52).map { Card.fromId(it) }.toMutableList()
        deck.shuffle()
        cutNumber = Random.nextInt(1, 52)
        repeat(cutNumber) { deck.add(deck.removeAt(0)) }

        // First 5: Hakem only. Do not expose the other first-five hands yet.
        repeat(5) { hands[hakem].add(deck.removeAt(0)) }
        phase = Phase.TRUMP
        turn = hakem
        leader = hakem
        trump = null
        tricks = intArrayOf(0, 0)
        trick.clear()
        streakTeam = -1
        streakCount = 0
        koot = false
        handWinnerTeam = -1
        message = "حاکم ۵ کارت خود را می‌بیند و حکم را انتخاب می‌کند."
    }

    fun chooseTrump(suit: Suit): Boolean {
        if (phase != Phase.TRUMP || turn != hakem) return false
        trump = suit
        // Complete the deal only after trump is declared.
        // The other three players first receive 5 each; then the remaining 32 cards
        // are dealt in 4-card packets in the same rotation, starting from Hakem.
        for (offset in 1..3) {
            val p = (hakem + offset) % 4
            repeat(5) { hands[p].add(deck.removeAt(0)) }
        }
        while (deck.isNotEmpty()) {
            for (offset in 0..3) {
                val p = (hakem + offset) % 4
                repeat(minOf(4, deck.size)) { hands[p].add(deck.removeAt(0)) }
                if (deck.isEmpty()) break
            }
        }
        phase = Phase.PLAY
        turn = hakem
        leader = hakem
        message = "حکم ${suit.symbol} است؛ ${playerNames[hakem]} شروع می‌کند."
        return true
    }

    fun handOf(player: Int): List<Card> = hands[player].sortedBy { it.id }
    fun currentTrick(): List<PlayedCard> = trick.toList()
    fun teamOf(player: Int): Int = teamOf[player]

    fun legal(card: Card, player: Int = turn): Boolean {
        if (phase != Phase.PLAY || trump == null || player != turn) return false
        if (!hands[player].contains(card)) return false
        if (trick.isEmpty()) return true
        val lead = trick.first().card.suit
        return card.suit == lead || hands[player].none { it.suit == lead }
    }

    fun play(card: Card, player: Int = turn): Boolean {
        if (!legal(card, player)) return false
        hands[player].remove(card)
        trick.add(PlayedCard(player, card))
        if (trick.size < 4) {
            turn = (player + 1) % 4
            message = "نوبت ${playerNames[turn]} است."
            return true
        }

        val winner = winnerOf(trick, trump!!)
        val winningTeam = teamOf[winner]
        tricks[winningTeam]++
        if (winningTeam == streakTeam) streakCount++
        else {
            streakTeam = winningTeam
            streakCount = 1
        }

        val opponent = 1 - winningTeam
        val shutout = tricks[opponent] == 0 && tricks[winningTeam] >= 7
        val sevenStraight = streakCount >= 7
        koot = shutout || sevenStraight
        handWinnerTeam = winningTeam

        if (tricks[winningTeam] >= 7) {
            phase = Phase.OVER
            score[winningTeam]++
            matchOver = score[winningTeam] >= MATCH_TARGET
            message = if (matchOver) {
                "بازی تمام شد — تیم ${winningTeam + 1} به ${MATCH_TARGET} امتیاز رسید."
            } else if (koot) {
                "${playerNames[winner]} دست را برد — کُت!"
            } else {
                "تیم ${winningTeam + 1} دست را برد."
            }
            trick.clear()
        } else {
            leader = winner
            turn = winner
            message = "${playerNames[winner]} چهارکارت را برد و شروع می‌کند."
            trick.clear()
        }
        return true
    }

    /** Apply the standard next-hand Hakem rotation: Hakem team keeps Hakem if it won;
     * otherwise the new Hakem is the opponent sitting to the current Hakem's right.
     * The user can then choose either member of the new Hakem team to cut. */
    fun prepareNextHand(): Int {
        if (phase != Phase.OVER || matchOver) return cutter
        val currentHakemTeam = teamOf[hakem]
        if (handWinnerTeam != currentHakemTeam) {
            // With positions clockwise 0->1->2->3, the next player to the Hakem's right is +1.
            hakem = (hakem + 1) % 4
        }
        // Default cutter is the opposite teammate of the new Hakem.
        cutter = (hakem + 2) % 4
        phase = Phase.LOBBY
        setupAllowed = false
        handWinnerTeam = -1
        message = "دست بعد آماده است؛ تیم‌ها و حاکم تغییر نمی‌کنند."
        clearCards()
        return cutter
    }

    fun setMessage(s: String) { message = s }

    private fun winnerOf(cards: List<PlayedCard>, trump: Suit): Int {
        val lead = cards.first().card.suit
        var best = cards.first()
        for (pc in cards.drop(1)) {
            val c = pc.card
            val b = best.card
            val cTrump = c.suit == trump
            val bTrump = b.suit == trump
            val better = when {
                cTrump && !bTrump -> true
                !cTrump && bTrump -> false
                cTrump && bTrump -> c.rank.value > b.rank.value
                c.suit == lead && b.suit != lead -> true
                c.suit == lead && b.suit == lead -> c.rank.value > b.rank.value
                else -> false
            }
            if (better) best = pc
        }
        return best.player
    }

    private fun clearCards() {
        hands = Array(4) { mutableListOf() }
        deck = mutableListOf()
        trick = mutableListOf()
        trump = null
        tricks = intArrayOf(0, 0)
        streakTeam = -1
        streakCount = 0
        koot = false
    }

    fun snapshotFor(player: Int): PublicSnapshot = PublicSnapshot(
        phase, hakem, cutter, turn, leader, trump, tricks.copyOf(), score.copyOf(),
        currentTrick(), streakTeam, streakCount, phase == Phase.OVER, koot, message, cutNumber, teamOf.copyOf(), matchOver, setupAllowed
    )
}
