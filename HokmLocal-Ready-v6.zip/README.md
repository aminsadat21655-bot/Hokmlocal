# حکم محلی — Hokm Local

نسخه‌ی آماده‌ی بازی حکم چهار نفره روی شبکه‌ی محلی Wi‑Fi برای اندروید.

## امکانات
- چهار بازیکن روی چهار گوشی، بدون اینترنت.
- یک گوشی میزبان است و سه گوشی با IP میزبان وارد می‌شوند.
- دو تیم ثابت: پایین+بالا در برابر راست+چپ.
- دسته‌ی ۵۲تایی بدون جوکر و ۱۳ کارت برای هر بازیکن.
- ابتدا فقط ۵ کارت حاکم پخش می‌شود و فقط حاکم حکم را می‌بیند و انتخاب می‌کند.
- رعایت خال اجباری است؛ اگر خال شروع‌شده را داشته باشی، نمی‌توانی خال دیگری بازی کنی.
- حکم همیشه بر خال‌های غیرحکم برتری دارد.
- برنده‌ی هر چهارکارت، چهارکارت بعدی را شروع می‌کند.
- اولین تیمی که به ۷ چهارکارت برسد، دست را می‌برد.
- کُت برای برد ۷-۰ ثبت می‌شود.
- امتیاز دست‌ها جدا از تعداد چهارکارت‌ها نگهداری می‌شود.
- پس از پایان دست، حاکم مطابق چرخش بازی به دست بعد منتقل می‌شود.
- میزبان مرجع اصلی بازی است و فقط حرکت بازیکن نوبت‌دار را قبول می‌کند.
- هر گوشی فقط کارت‌های خودش را دریافت می‌کند؛ دست بازیکنان دیگر روی شبکه ارسال نمی‌شود.
- رابط گرافیکی جدید با میز سبز، کارت‌های واقعی‌تر، نشان بازیکنان، وضعیت حاکم، حکم، امتیاز و پنل‌های بازی.
- IP میزبان با اولویت آدرس Wi‑Fi نمایش داده می‌شود تا احتمال انتخاب IP مربوط به VPN کمتر شود.

## ساخت APK با گوشی
این پروژه برای GitHub Actions آماده شده است. اگر پروژه را داخل یک repository به‌صورت فایل ZIP قرار می‌دهی، Workflow بیرونی باید ZIP را استخراج کند و سپس `:app:assembleDebug` را اجرا کند.

## تنظیمات Build
- Android Gradle Plugin: 8.7.3
- Gradle: 8.9
- JDK: 17
- compileSdk / targetSdk: 35
- minSdk: 24
- Java/Kotlin JVM target: 17

تنظیم Java و Kotlin عمداً روی JVM 17 یکسان شده است تا خطای `Inconsistent JVM-target compatibility` ایجاد نشود. راهنمای رسمی Android نیز برای پروژه‌های Android توصیه می‌کند `sourceCompatibility` و `targetCompatibility` و در Kotlinهای قدیمی‌تر `jvmTarget` صریحاً هماهنگ شوند.

## تست
من موتور قوانین بازی را با Kotlin به‌صورت مستقل کامپایل و اجرا کردم و یک تست تصادفی ۵۰۰ دست انجام شد؛ در هر دست ۵۲ کارت یکتا، ۱۳ کارت برای هر بازیکن، اجبار رعایت خال و پایان دست در ۷ برد بررسی شد.

ساخت کامل APK در این محیط به‌دلیل نبود Android SDK قابل اجرای محلی نبود؛ برای همین Workflow GitHub Actions در پروژه با JDK 17 و Gradle 8.9 تنظیم شده تا Build واقعی اندروید را انجام دهد.

## Wi‑Fi / LAN behavior

- On Android 13+, the app requests `NEARBY_WIFI_DEVICES` and tries to start an Android Local-Only Hotspot for the host. This creates a local network with no internet access.
- If the phone/ROM refuses Local-Only Hotspot (for example because another hotspot mode is already active), the app falls back to clear manual Wi‑Fi/Hotspot instructions.
- Android does not allow an ordinary app to silently turn Wi‑Fi on/off on modern versions. For joining, the app opens the system Wi‑Fi panel so the user can enable Wi‑Fi and connect to the host network.
- The host lobby displays the SSID, password, and detected private IP address for the LAN server.
- A visible Back button and Android back action return to the home screen and close the LAN session/hotspot reservation.

## v5 offline self-test

The app does not expose a self-test mode. Setup controls are available only in the initial lobby and after the complete match ends; between hands the selected teams and Hakem remain fixed.
